import javax.swing.*;

public class IMAGE_MDL{
    private ImageIcon[] images = new ImageIcon[1];
    int cnt = 0;

    public void addImage(ImageIcon img){
        images[cnt++] = img;

        ImageIcon[] temp = new ImageIcon[images.length+1];
        for (int i = 0; i < images.length; i++){
            temp[i] = images[i];
        }
        images = temp;
    }
    public ImageIcon[] getImages(){
        return images;
    }
}