public class Main {
    public static void main(String[] args){
        IMAGE_MDL model = new IMAGE_MDL();
        IMAGE_VIEW view = new IMAGE_VIEW();
        IMAGE_CNTRLR cntrlr = new IMAGE_CNTRLR(model, view);
        cntrlr.start();
    }
}
