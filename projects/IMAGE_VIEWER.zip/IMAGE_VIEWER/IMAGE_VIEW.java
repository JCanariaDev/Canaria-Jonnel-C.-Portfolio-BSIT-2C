 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class IMAGE_VIEW extends JFrame{
    private JLabel header = new JLabel("Image Viewer");
    private JButton next = new JButton("next");
    private JButton prev = new JButton("previous");
    private JPanel midPanel = new JPanel(null);
    private JLabel midContainer = new JLabel();

    //debug----------
    ImageIcon ima = new ImageIcon("Screenshot 2024-05-10 205449.png");
    //debug---------

    public IMAGE_VIEW(){
        currentImage(ima);//initialize the image
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setBounds(190, 20, 200, 50);
        header.setBackground(Color.BLACK);
        header.setOpaque(true);
        header.setForeground(Color.WHITE);
        header.setHorizontalAlignment(JLabel.CENTER);
        header.setVerticalAlignment(JLabel.CENTER);


        midContainer.setBounds(0, 0, 400, 400);//the label
        midPanel.setBounds(100, 100, 400, 400);//the panel

        next.setBounds(300, 570, 200, 50);
        next.setFont(new Font("Arial", Font.BOLD, 20));
        next.setBackground(Color.BLUE);
        next.setForeground(Color.WHITE);
        next.setFocusable(false);
        prev.setBounds(100, 570, 150, 50);
        prev.setFont(new Font("Arial", Font.BOLD, 20));
        prev.setBackground(Color.RED);
        prev.setForeground(Color.WHITE);
        prev.setFocusable(false);

        getContentPane().setBackground(Color.GRAY);

        this.setLayout(null);
        this.setSize(600,800);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.add(header);
        this.add(midPanel); 
        this.add(next);
        this.add(prev);
        this.setVisible(true);
        this.setResizable(false);
        this.setTitle("Image Viewer ni Jonnel Canaria");
    }

    public void currentImage(ImageIcon image) {
        midContainer.setIcon(image);
        //imageContainer.setSize(image.getIconWidth(), image.getIconHeight());
        midPanel.add(midContainer);//initialize
        revalidate();
    }

    public void nextImage(ImageIcon image) {
        midContainer.setIcon(image);
        //imageContainer.setSize(image.getIconWidth(), image.getIconHeight());
        revalidate();
    }

    public void addActionNext(ActionListener act){
        next.addActionListener(act);
    }
    public void addActionPrev(ActionListener act){
        prev.addActionListener(act);
    }
    public void setVisibleImageViewer(){
        this.setVisible(true);
    }

}