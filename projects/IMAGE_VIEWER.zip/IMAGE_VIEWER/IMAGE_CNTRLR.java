import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

public class IMAGE_CNTRLR extends Thread{
    private IMAGE_MDL model;
    private IMAGE_VIEW view;
    //debug-----------------------------------------------
    ImageIcon ima1 = new ImageIcon("Screenshot 2024-05-10 205449.png");
    ImageIcon ima2 = new ImageIcon("Screenshot 2024-05-07 062052.png");
    ImageIcon ima3 = new ImageIcon("Screenshot 2024-05-07 061929.png");
    private ImageIcon[] arr = {ima1, ima2, ima3};
    //debug------------------------------------------------

    private int counter = 0;

    public IMAGE_CNTRLR(IMAGE_MDL model, IMAGE_VIEW view){
        this.model = model;
        this.view = view;

        model.addImage(ima1);
        model.addImage(ima2);
        model.addImage(ima3);
    }

    
    public void run(){//ito na po sir, at ang hirap kung saan iaaply ung thread hahahahahahahahahahahahah
        view.addActionNext(new next());
        view.addActionPrev(new prev());
    }
    class next implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ImageIcon[] images = model.getImages();
            //String command = e.getActionCommand();
            //debug-----------------------
                try {
                    Thread.sleep(500); // Change image every 0.5 seconds
                } catch (InterruptedException error) {
                    error.printStackTrace();
                }
                if (counter == 0){
                    view.nextImage(images[1]);
                    counter = 1;
                } else if (counter == 1){
                    view.nextImage(images[2]);
                    counter = 2;
                } else if (counter == 2){
                    view.nextImage(images[0]);
                    counter = 0;
                }
                //debug---------------------------
        }
    }
    class prev implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ImageIcon[] images = model.getImages();
            //String command = e.getActionCommand();
            //debug-----------------------
                try {
                    Thread.sleep(500); // Change image every 0.5 seconds
                } catch (InterruptedException error) {
                    error.printStackTrace();
                }
                if (counter == 0){
                    //view.nextImage(arr[0]);
                    //counter = 1;
                    return;
                } else if (counter == 1){
                    view.nextImage(images[0]);
                    counter = 0;
                } else if (counter == 2){
                    view.nextImage(images[1]);
                    counter = 1;
                }
                //debug---------------------------
        }
    }
}
