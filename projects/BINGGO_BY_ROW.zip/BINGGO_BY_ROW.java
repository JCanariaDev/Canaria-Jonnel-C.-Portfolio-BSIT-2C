//package mayLetterSaKatabi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class BINGGO_BY_ROW {
        private static final ArrayList<Integer> naCallNaNumber = new ArrayList<>(); // SAME----
        private static final String[][] shuffledBingoValues = shuffleBingoValues();

        private static final int ROWS = 5;
        private static final int COLUMNS = 5;
        public static final String ANSI_RESET = "\u001B[0m";
        public static final String ANSI_RED = "\u001B[31m";
        public static final String ANSI_GREEN = "\u001B[32m";
        public static final String ANSI_YELLOW = "\u001B[33m";
        public static final String ANSI_ORANGE = "\u001B[38;5;208m";
        public static final String ANSI_AQUA = "\u001B[36m";
        public static final String ANSI_LIGHT_VIOLET = "\u001B[95m";
        public static final String ANSI_BLACK = "\u001B[30m";
        public static final String ANSI_GOLD = "\u001B[33m";

        final int[][] bingoCard;
        final String cardIdentifier; // Identifier for the Bingo card
        private static int nextNumberIndex = 0;

        private static final BINGGO_BY_ROW
[] allGames = new BINGGO_BY_ROW
[5]; // Array to hold all Bingo games
        private static final ArrayList<Integer> numberQueue = new ArrayList<>(); // Queue to hold called numbers SAME---

        public BINGGO_BY_ROW
(String cardIdentifier) {
                this.cardIdentifier = cardIdentifier;
                bingoCard = new int[ROWS][COLUMNS];

                // Generate the Bingo card
                ArrayList<Integer> cardNumbers = generateCard();
                int index = 0;
                for (int i = 0; i < ROWS; i++) {
                        for (int j = 0; j < COLUMNS; j++) {
                                bingoCard[i][j] = cardNumbers.get(index++);
                        }
                }
        }

        private ArrayList<Integer> generateCard() {
                ArrayList<Integer> card = new ArrayList<>();

                ArrayList<Integer> numbersB = generateColumnNumbers(1, 15);
                ArrayList<Integer> numbersI = generateColumnNumbers(16, 30);
                ArrayList<Integer> numbersN = generateColumnNumbers(31, 45);
                ArrayList<Integer> numbersG = generateColumnNumbers(46, 60);
                ArrayList<Integer> numbersO = generateColumnNumbers(61, 75);

                Collections.shuffle(numbersB);
                Collections.shuffle(numbersI);
                Collections.shuffle(numbersN);
                Collections.shuffle(numbersG);
                Collections.shuffle(numbersO);

                for (int i = 0; i < ROWS; i++) {
                        card.add(numbersB.get(i));
                        card.add(numbersI.get(i));
                        if (i == 2) {
                                // Add empty cell for the middle cell of column N
                                card.add(0);
                        } else {
                                card.add(numbersN.get(i));
                        }
                        card.add(numbersG.get(i));
                        card.add(numbersO.get(i));
                }

                return card;
        }

        private ArrayList<Integer> generateColumnNumbers(int start, int end) {
                ArrayList<Integer> numbers = new ArrayList<>();
                for (int i = start; i <= end; i++) {
                        numbers.add(i);
                }
                return numbers;
        }

        void printBingoCard() {

                System.out.println(
                                "                                                                      ------------- BINGO CARD "
                                                + cardIdentifier + " -------------");
                System.out.println(
                                "                                                                            ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                                            ▐   B    I    N    G    O  ▌");
                System.out.println(
                                "                                                                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                for (int i = 0; i < ROWS; i++) {
                        System.out.print(
                                        "                                                                             ▌ ");
                        for (int j = 0; j < COLUMNS; j++) {
                                if (bingoCard[i][j] == 0) {
                                        System.out.print("\u001B[31mX\u001B[0m  ▐ "); // Marked off numbers
                                } else {
                                        System.out.print(String.format("%2d ▐ ", bingoCard[i][j]));
                                }
                        }
                        System.out.println();
                }
                System.out.println(
                                "                                                                            ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀");
                System.out.println();
        }

        private static String getLetterForNumber(int number) {
                if (number >= 1 && number <= 15) {
                        return "B";
                } else if (number >= 16 && number <= 30) {
                        return "I";
                } else if (number >= 31 && number <= 45) {
                        return "N";
                } else if (number >= 46 && number <= 60) {
                        return "G";
                } else {
                        return "O";
                }
        }

        private static boolean isStraightVertical(int[][] card) {
                for (int i = 0; i < 5; i++) {
                        if (card[i][0] == 0 && card[i][1] == 0 && card[i][2] == 0 && card[i][3] == 0
                                        && card[i][4] == 0) {
                                return true;
                        }
                }
                return false;
        }

        private static boolean isStraightHorizontal(int[][] card) {
                for (int j = 0; j < 5; j++) {
                        if (card[0][j] == 0 && card[1][j] == 0 && card[2][j] == 0 && card[3][j] == 0
                                        && card[4][j] == 0) {
                                return true;
                        }
                }
                return false;
        }

        private static boolean isDiagonal(int[][] card) {
                return (card[0][0] == 0 && card[1][1] == 0 && card[2][2] == 0 && card[3][3] == 0 && card[4][4] == 0) ||
                                (card[0][4] == 0 && card[1][3] == 0 && card[2][2] == 0 && card[3][1] == 0
                                                && card[4][0] == 0);
        }

        private static boolean isCross(int[][] card) {
                return (card[0][0] == 0 && card[1][1] == 0 && card[2][2] == 0 && card[3][3] == 0 && card[4][4] == 0) ||
                                (card[0][4] == 0 && card[1][3] == 0 && card[2][2] == 0 && card[3][1] == 0
                                                && card[4][0] == 0)
                                ||
                                (card[0][2] == 0 && card[1][1] == 0 && card[2][2] == 0 && card[3][3] == 0
                                                && card[4][4] == 0)
                                ||
                                (card[0][2] == 0 && card[1][3] == 0 && card[2][2] == 0 && card[3][1] == 0
                                                && card[4][0] == 0);
        }

        private static boolean isFull(int[][] card) {
                if (card == null) {
                        return false; // If card is null, it can't be full
                }
                for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 5; j++) {
                                if (card[i][j] != 0) {
                                        return false;
                                }
                        }
                }
                return true;
        }

        public static String checkWinningPatterns() {
                String winner = "";

                // Check each game for winning patterns
                for (BINGGO_BY_ROW
         game : allGames) {
                        if (isStraightVertical(game.bingoCard) || isStraightHorizontal(game.bingoCard)
                                        || isDiagonal(game.bingoCard) || isCross(game.bingoCard)) {
                                winner = game.cardIdentifier;
                                break; // Break out of the loop if any winning pattern is found
                        }
                }

                if (winner.equals("") && isFull(null)) {
                        winner = "Full House"; // Full house
                }

                return winner;
        }

        // DEBUGGINNG------------------------------------------------------------------------
        private static void printNaCallNa() {
                int cellWidth = 7;

                System.out.println(
                                "                                                            ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                            ▐       B          I          N          G          O     ▌");
                System.out.println(
                                "                                                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");

                for (int i = 0; i < shuffledBingoValues.length; i++) {
                        System.out.print("                                                            ▐");
                        for (int j = 0; j < shuffledBingoValues[i].length; j++) {
                                String value = shuffledBingoValues[i][j];
                                // Adjust the spacing to center the value within the cell
                                int spacesBefore = (cellWidth - value.length()) / 2;
                                int spacesAfter = cellWidth - value.length() - spacesBefore;
                                String n = value.strip();
                                //DEBUGGING-----------------
                                if (n == "\u001B[31mX\u001B[0m".strip()){
                                        System.out.print("       \u001B[31mX\u001B[0m   ");
                                         
                                }
                                //-----------------------
       
                                else {
                                        System.out.print("   ".repeat(spacesBefore) + value + " ".repeat(spacesAfter));
                                }
                        }
                        System.out.println("  ▌");
                        System.out.println(
                                        "                                                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                }
        }

        private static void printBingoValues() {
                int cellWidth = 7;
                String[][] bingoValues = {
                                { " 1", "16", "31", "46", "61" },
                                { " 2", "17", "32", "47", "62" },
                                { " 3", "18", "33", "48", "63" },
                                { " 4", "19", "34", "49", "64" },
                                { " 5", "20", "35", "50", "65" },
                                { " 6", "21", "36", "51", "66" },
                                { " 7", "22", "37", "52", "67" },
                                { " 8", "23", "38", "53", "68" },
                                { " 9", "24", "39", "54", "69" },
                                { "10", "25", "40", "55", "70" },
                                { "11", "26", "41", "56", "71" },
                                { "12", "27", "42", "57", "72" },
                                { "13", "28", "43", "58", "73" },
                                { "14", "29", "44", "59", "74" },
                                { "15", "30", "45", "60", "75" }
                };
                System.out.println(
                                "                                                            ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                            ▐       B          I          N          G          O     ▌");
                System.out.println(
                                "                                                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");

                for (int i = 0; i < bingoValues.length; i++) {
                        System.out.print("                                                            ▐");
                        for (int j = 0; j < bingoValues[i].length; j++) {
                                String value = bingoValues[i][j];
                                // Adjust the spacing to center the value within the cell
                                int spacesBefore = (cellWidth - value.length()) / 2;
                                int spacesAfter = cellWidth - value.length() - spacesBefore;
                                System.out.print("   ".repeat(spacesBefore) + value + " ".repeat(spacesAfter));
                        }
                        System.out.println("  ▌");
                        System.out.println(
                                        "                                                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                }
        }

        private static String[][] shuffleBingoValues() {
                String[][] bingoValues = {
                                { " 1", "16", "31", "46", "61" },
                                { " 2", "17", "32", "47", "62" },
                                { " 3", "18", "33", "48", "63" },
                                { " 4", "19", "34", "49", "64" },
                                { " 5", "20", "35", "50", "65" },
                                { " 6", "21", "36", "51", "66" },
                                { " 7", "22", "37", "52", "67" },
                                { " 8", "23", "38", "53", "68" },
                                { " 9", "24", "39", "54", "69" },
                                { "10", "25", "40", "55", "70" },
                                { "11", "26", "41", "56", "71" },
                                { "12", "27", "42", "57", "72" },
                                { "13", "28", "43", "58", "73" },
                                { "14", "29", "44", "59", "74" },
                                { "15", "30", "45", "60", "75" }
                };

                // Shuffle each column independently
                for (int i = 0; i < bingoValues[0].length; i++) {
                        String[] columnValues = new String[bingoValues.length];
                        for (int j = 0; j < bingoValues.length; j++) {
                                columnValues[j] = bingoValues[j][i];
                        }
                        shuffleArray(columnValues);
                        for (int j = 0; j < bingoValues.length; j++) {
                                bingoValues[j][i] = columnValues[j];
                        }
                }

                printBingoValues(bingoValues);
                return bingoValues;
        }

        private static void shuffleArray(String[] array) {
                Random rand = new Random();
                for (int i = array.length - 1; i > 0; i--) {
                        int index = rand.nextInt(i + 1);
                        String temp = array[index];
                        array[index] = array[i];
                        array[i] = temp;
                }
        }

        private static void printBingoValues(String[][] bingoValues) {
                int cellWidth = 7; // Adjust this value to change the width of each cell
                System.out.println(
                                "                                                            ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                            ▐       B          I          N          G          O     ▌");
                System.out.println(
                                "                                                            ▐       V          A          L          U          E     ▌");
                System.out.println(
                                "                                                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");

                for (int i = 0; i < bingoValues.length; i++) {
                        System.out.print("                                                            ▐");
                        for (int j = 0; j < bingoValues[i].length; j++) {
                                String value = bingoValues[i][j];
                                // Adjust the spacing to center the value within the cell
                                int spacesBefore = (cellWidth - value.length()) / 2;
                                int spacesAfter = cellWidth - value.length() - spacesBefore;
                                System.out.print("   ".repeat(spacesBefore) + value + " ".repeat(spacesAfter));
                        }
                        System.out.println("  ▌");
                        System.out.println(
                                        "                                                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                }
        }

        private static void MGATAOSAGROUP() {
                System.out.println(" GH ");
                System.out.println(" GD ");
                System.out.println("GD ");
        }

        public static void main(String[] args) {
                MGATAOSAGROUP();
                System.out.println(ANSI_GREEN + "");
                System.out.println("");

                System.out.println(
                                "                                                                          " + ANSI_RED
                                                + " ██  ██  " + ANSI_GREEN
                                                + "                                                           "
                                                + ANSI_RED + "  █  ██  " + ANSI_GREEN + "                      ");
                System.out.println(
                                "                   " + ANSI_RED + " █  ██ " + ANSI_GREEN
                                                + "                                              " + ANSI_RED
                                                + " ██████ " + ANSI_GREEN
                                                + "                                                           "
                                                + ANSI_RED + "  ██████  " + ANSI_GREEN + "                        ");
                System.out.println(
                                "                 " + ANSI_RED + " ████ " + ANSI_GREEN
                                                + "                                                   " + ANSI_RED
                                                + " ██ " + ANSI_RED + "  ███ " + ANSI_YELLOW
                                                + "██████████                                                "
                                                + ANSI_RED + "  ██  ███ " + ANSI_GREEN + "  ");
                System.out.println(
                                "                " + ANSI_RED + "  ████    █ " + ANSI_GREEN
                                                + "                                        " + ANSI_YELLOW + "  ███    "
                                                + ANSI_RED + "   ██ " + ANSI_YELLOW
                                                + " ████    ███     ██████████                                    "
                                                + ANSI_RED + "  █    ");
                System.out.println(
                                "                    █    ██ " + ANSI_GREEN + "                                       "
                                                + ANSI_YELLOW
                                                + "  ████         ████           █████   █████              ");
                System.out.println(
                                "                                                              ███     ███         ███            ███       ████      ██     ");
                System.out.println(
                                "                                                          ████████    ████        ████          ████       ████     █████            ");
                System.out.println(
                                "                                                       ███████         ████       ████      ██  ████       ███    ██████     "
                                                + ANSI_GREEN + "                       ██████    ███   ");
                System.out.println(
                                "                                                     " + ANSI_YELLOW
                                                + "  █████    ███     ███      ██████████████ ████      ████   ███████     ███ "
                                                + ANSI_GREEN + "                 ██████████████████  ");
                System.out.println(
                                "                                                 " + ANSI_YELLOW
                                                + " ██     ██████████     ████████████ ████████    ████████████   ███████   ███████  "
                                                + ANSI_GREEN + "              ████████████████████ ");
                System.out.println(
                                "                                               " + ANSI_YELLOW
                                                + "  ████     ██████         ████████                  ████████   █████ ████████████  "
                                                + ANSI_GREEN + "               ███████████████████████  ");
                System.out.println(
                                "                                               " + ANSI_YELLOW
                                                + "   ████     ████     ████  █                                  ████  ███████████   "
                                                + ANSI_GREEN + "              ███████████████████████████  ");
                System.out.println(
                                "                                            " + ANSI_YELLOW
                                                + "  ██    ████    ██████████                                        ██   █████ ████       ███ "
                                                + ANSI_GREEN + "       ████████████████████████████ ");
                System.out.println(
                                "                                         " + ANSI_YELLOW
                                                + "   ███████  ████    ██████                                               ███   ████      ██████ "
                                                + ANSI_GREEN + "     █████████████████████████████  ");
                System.out.println(
                                "                                           " + ANSI_YELLOW
                                                + "   ████████████    ██                                                      ████     ██████ ████  "
                                                + ANSI_GREEN + "   ███████████████████████████ ");
                System.out.println(
                                "                                        " + ANSI_YELLOW
                                                + " ██    ████ █████████                  ██████████   ██████                    ███    ███████   ████  "
                                                + ANSI_GREEN + "   █████████████████████████   ");
                System.out.println(
                                "      █████                            " + ANSI_YELLOW
                                                + " ██████  ████    ████                   ██ ████ ██ ███████████                    ███████ ████    ███  "
                                                + ANSI_GREEN + "    ██████████████████████ ");
                System.out.println(
                                "      ███████                       ██   " + ANSI_YELLOW
                                                + "  ███████████                            ████   ████    ████                     ████    █████  █    "
                                                + ANSI_GREEN + "      ████████████████████  ");
                System.out.println(
                                "      ████████         ███      ███████    " + ANSI_YELLOW
                                                + "    █████████                          ████   ████    ████                      █████   ██    "
                                                + ANSI_GREEN + "            ███████ ██████████ ");
                System.out.println(
                                "      █████████      ██████████████████      " + ANSI_YELLOW
                                                + "      ████                           ████    ████  ████                         ████         "
                                                + ANSI_GREEN + "              ███   ████████   ");
                System.out.println(
                                "      ██████████████████████████████                                            "
                                                + ANSI_YELLOW + " ██████    ████████         " + ANSI_RED
                                                + "   ██       " + ANSI_YELLOW + "     ████               " + ANSI_GREEN
                                                + "       ███ ████  ");
                System.out.println(
                                "      █████████   ██████████████                                                                             "
                                                + ANSI_RED + " ██████       " + ANSI_YELLOW + "    █          "
                                                + ANSI_GREEN + "               ██████   ");
                System.out.println(
                                "      ████████     █████████                                                                                "
                                                + ANSI_RED + "    ██   ██                     " + ANSI_GREEN
                                                + "             █████  ");
                System.out.println(
                                "      ███████      ██████████                                                                                                                             ███   ");
                System.out.println(
                                "      ██████████████████████         " + ANSI_RED
                                                + "         ████████                                                                        ████████       "
                                                + ANSI_GREEN + "             ███ ");
                System.out.println(
                                "      ███████████████████           " + ANSI_RED
                                                + "       █████████████                                                                    █████████████      "
                                                + ANSI_GREEN + "           ██ ");
                System.out.println(
                                "      █████████████████            " + ANSI_RED + "       ██████ ██ ██████  "
                                                + ANSI_YELLOW
                                                + " █████████   ███████████   ██████   ███████      ███████    "
                                                + ANSI_RED + "  ███████ █ ██████        " + ANSI_GREEN + "        ██ ");
                System.out.println(
                                "      ████████████████          " + ANSI_RED + "    █    █████  ███   █████  "
                                                + ANSI_YELLOW
                                                + "  ███  ████  ████   █████   ██   ████   ████  ███    ████  "
                                                + ANSI_RED + "  █████  ███  █████         " + ANSI_GREEN
                                                + "     ███  ");
                System.out.println(
                                "      █████████████           " + ANSI_RED + "  ██       ██████████████████  "
                                                + ANSI_YELLOW
                                                + "  ███  ███   ████   ██████  ██  ████    ███  ███      ████ "
                                                + ANSI_RED + " ██████████████████        " + ANSI_GREEN
                                                + "      ███  ");
                System.out.println(
                                "      █████████████          " + ANSI_RED + "  ████      ██████████████████  "
                                                + ANSI_YELLOW
                                                + "  █████████  ████   ██ ███████  ████         ███      ████ "
                                                + ANSI_RED + "  █████████████████         " + ANSI_GREEN
                                                + "     ████ ");
                System.out.println(
                                "      █████████████            " + ANSI_RED + "  █   ██   ███████  ███████   "
                                                + ANSI_YELLOW
                                                + "  ███   ███  ████   ██   █████  ████   █████████      ████  "
                                                + ANSI_RED + " ███████  ████████        " + ANSI_GREEN
                                                + "      ████  ");
                System.out.println(
                                "      ██████████████                " + ANSI_RED + "       ██████████████    "
                                                + ANSI_YELLOW
                                                + "  ███  ████  ████   ██    ████   ████   ███   ████   ████  "
                                                + ANSI_RED + "   ███████████████    " + ANSI_GREEN + "     ");
                System.out.println(
                                "      ██████████████                    " + ANSI_RED + "     ██████████    "
                                                + ANSI_YELLOW
                                                + "   █████████  ██████ █████    ██    █████████    ████████     "
                                                + ANSI_RED + "    ███████████   " + ANSI_RESET);
                System.out.println("\n");
                System.out.println(
                                "                                                            " + ANSI_GREEN
                                                + "  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                              ▐                 Type <go> To Continue!              ▌");
                System.out.println(
                                "                                                              ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                promptUser2(
                                "                                                                                      >>>");
                Scanner scanner = new Scanner(System.in);

                System.out.println("");
                System.out.println("\n\n\n");
                System.out.println(ANSI_LIGHT_VIOLET +
                                "                                                                                         ██          ██    ");
                System.out.println(
                                "                                                                                        █████     ████████  ");
                System.out.println(
                                "                                                                                 ███████████    █████   ███ ");
                System.out.println(
                                "                                                                          █████████████████    █████     ██ ");
                System.out.println(
                                "                                                                   ██████   ████████████        █████  ");
                System.out.println(
                                "                                                              ███████████      █████             █████████  ");
                System.out.println(
                                "                                                            ███████             █████             ██████████               "
                                                + ANSI_AQUA + "  ███    ");
                System.out.println(
                                "                                               " + ANSI_LIGHT_VIOLET
                                                + "  ████        █████             ██████                 ██████             "
                                                + ANSI_AQUA + "     ██          ██  ");
                System.out.println(
                                "                                              " + ANSI_LIGHT_VIOLET
                                                + "  ██████       ████████████       █████              ████████               "
                                                + ANSI_AQUA + "    ██  ██    ███   ");
                System.out.println(
                                "                                               " + ANSI_LIGHT_VIOLET
                                                + "  █████        ██████████        ██████         █████████                   "
                                                + ANSI_AQUA + "    █  ███  ███  ");
                System.out.println(
                                "                                                " + ANSI_LIGHT_VIOLET
                                                + " ██████       █████               █████                                     "
                                                + ANSI_AQUA + "    ██  █ ██  ");
                System.out.println(
                                "                                                " + ANSI_LIGHT_VIOLET
                                                + "  ██████       ████   ███████    ██████                              "
                                                + ANSI_RED + "         ███████   ");
                System.out.println(
                                "                                               " + ANSI_LIGHT_VIOLET
                                                + "    █████       ████  ███████      ██                                     "
                                                + ANSI_RED + "   ██████████   ");
                System.out.println(
                                "                                               " + ANSI_LIGHT_VIOLET
                                                + "    █████   ████ █████████                              ██    █████       "
                                                + ANSI_RED + "  ████████████    ");
                System.out.println(
                                "                                               " + ANSI_LIGHT_VIOLET
                                                + "     ███████████  █████                    ████     ██████   █████        "
                                                + ANSI_RED + " ██████████████  ");
                System.out.println(
                                "                             " + ANSI_AQUA + "        ███████      "
                                                + ANSI_LIGHT_VIOLET
                                                + "  ██████████                          ███████     ██████ █████          "
                                                + ANSI_RED + " ████████████     ");
                System.out.println(
                                "                              " + ANSI_AQUA + "    ██████████████    "
                                                + ANSI_LIGHT_VIOLET
                                                + " ████                              █████████     ███████████         "
                                                + ANSI_RED + "   ██████████ ");
                System.out.println(
                                "                                " + ANSI_AQUA + "  ██████████████     "
                                                + ANSI_LIGHT_VIOLET
                                                + "                 █████            ██████████     █████████          "
                                                + ANSI_RED + "    ████████      ");
                System.out.println(
                                "                               " + ANSI_AQUA + "  ████████████████       "
                                                + ANSI_LIGHT_VIOLET
                                                + "              ██████           █████ █████     ████████        "
                                                + ANSI_RED + "   █████████████   ");
                System.out.println(
                                "                          " + ANSI_YELLOW + "    ██████████████████████     "
                                                + ANSI_LIGHT_VIOLET
                                                + "    ███████   ██████         █████   █████    ███████         "
                                                + ANSI_RED + "  ████████████████ ");
                System.out.println(
                                "                            " + ANSI_YELLOW + "   ████████████████████     "
                                                + ANSI_LIGHT_VIOLET
                                                + "  ████████████ ██████         █████████████     ██████         "
                                                + ANSI_RED + " ███ █████████  ███  ");
                System.out.println(
                                "                              " + ANSI_YELLOW + "   ████████████████      "
                                                + ANSI_LIGHT_VIOLET
                                                + " ████████ ██████ ██████        █████    █████    ██████       "
                                                + ANSI_RED + "   ██ ███████████ ███    ");
                System.out.println(
                                "                                " + ANSI_YELLOW + "    ██████████          "
                                                + ANSI_LIGHT_VIOLET
                                                + " ██████   █████ ██████     ██ ████     █████   ██████      "
                                                + ANSI_RED + "    ███ ███████████ ██  ");
                System.out.println(
                                "                                  " + ANSI_YELLOW + "    ██████             "
                                                + ANSI_LIGHT_VIOLET
                                                + " ██████ ██████  █████   ████ █████     █████                  "
                                                + ANSI_RED + "    ████████████  ");
                System.out.println(
                                "                                    " + ANSI_YELLOW + "   ████             "
                                                + ANSI_LIGHT_VIOLET
                                                + "  ████████████    ██████████                                      "
                                                + ANSI_RED + "   ████████ ");
                System.out.println(
                                "                                      " + ANSI_YELLOW + " ████               "
                                                + ANSI_LIGHT_VIOLET
                                                + " ██████         █████████                                      "
                                                + ANSI_RED + "   ██████████   ");
                System.out.println(
                                "                                " + ANSI_YELLOW + "   █████████████           "
                                                + ANSI_LIGHT_VIOLET
                                                + " ██████         ███                                          "
                                                + ANSI_RED + "   ████████████ ");
                System.out.println(
                                "                                " + ANSI_YELLOW + "   █████████████      " + ANSI_GREEN
                                                + "  █  " + ANSI_LIGHT_VIOLET
                                                + "  ██████                                           " + ANSI_RED
                                                + "  ████████████████████████████████  ");
                System.out.println(
                                "                                                " + ANSI_GREEN + "     ███████ "
                                                + ANSI_LIGHT_VIOLET + " ██████                                       "
                                                + ANSI_RED + "     █                              █ ");
                System.out.println(
                                "                                                  " + ANSI_GREEN + "      ██    "
                                                + ANSI_LIGHT_VIOLET + " ██                                         "
                                                + ANSI_RED + "      █                              █  ");
                System.out.println(
                                "                                                 " + ANSI_GREEN
                                                + "  █    █                                                   "
                                                + ANSI_RED + "    █                              █  ");
                System.out.println(
                                "                                                                                                           "
                                                + ANSI_RED + "     █                              █ ");
                System.out.println(
                                "                                                                                                                ████████████████████████████████  "
                                                + ANSI_RESET);
                System.out.println("\n");
                System.out.println(ANSI_YELLOW +
                                "                                                              ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                              ▐            Enter the name for Bingo Card 1:         ▌");
                System.out.println(
                                "                                                              ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                String card1Name = scanner.nextLine();
                System.out.println(ANSI_RED +
                                "                                                              ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                              ▐            Enter the name for Bingo Card 2:         ▌");
                System.out.println(
                                "                                                              ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                String card2Name = scanner.nextLine();
                System.out.println(ANSI_ORANGE +
                                "                                                              ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                              ▐            Enter the name for Bingo Card 3:         ▌");
                System.out.println(
                                "                                                              ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                String card3Name = scanner.nextLine();
                System.out.println(ANSI_LIGHT_VIOLET +
                                "                                                              ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                              ▐            Enter the name for Bingo Card 4:         ▌");
                System.out.println(
                                "                                                              ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                String card4Name = scanner.nextLine();
                System.out.println(ANSI_AQUA +
                                "                                                              ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                              ▐            Enter the name for Bingo Card 5:         ▌");
                System.out.println(
                                "                                                              ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                String card5Name = scanner.nextLine();
                System.out.println("");
                System.out.println("");
                System.out.println(ANSI_GREEN +
                                "                                                                   ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                                   ▐           Naming Cards, Completed!        ▌");
                System.out.println(
                                "                                                                   ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                allGames[0] = new BINGGO_BY_ROW
        (card1Name);
                allGames[1] = new BINGGO_BY_ROW
        (card2Name);
                allGames[2] = new BINGGO_BY_ROW
        (card3Name);
                allGames[3] = new BINGGO_BY_ROW
        (card4Name);
                allGames[4] = new BINGGO_BY_ROW
        (card5Name);

                System.out.println(
                                "                                                                          ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                                          ▐        Want to proceed?      ▌");
                System.out.println(
                                "                                                                          ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                promptUser(
                                "");
                System.out.println("");
                System.out.println("");
                System.out.println(ANSI_YELLOW +
                                "                                                 ██╗     ███████╗████████╗███████╗    ███████╗████████╗ █████╗ ██████╗ ████████╗██╗");
                System.out.println(
                                "                                                 ██║     ██╔════╝╚══██╔══╝██╔════╝    ██╔════╝╚══██╔══╝██╔══██╗██╔══██╗╚══██╔══╝██║");
                System.out.println(
                                "                                                 ██║     █████╗     ██║   ███████╗    ███████╗   ██║   ███████║██████╔╝   ██║   ██║");
                System.out.println(
                                "                                                 ██║     ██╔══╝     ██║   ╚════██║    ╚════██║   ██║   ██╔══██║██╔══██╗   ██║   ╚═╝");
                System.out.println(
                                "                                                 ███████╗███████╗   ██║   ███████║    ███████║   ██║   ██║  ██║██║  ██║   ██║   ██╗");
                System.out.println(
                                "                                                 ╚══════╝╚══════╝   ╚═╝   ╚══════╝    ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝");
                System.out.println("");
                System.out.println("");
                printBingoValues();
                System.out.println("\n");
                System.out.println(ANSI_RED +
                                "                                                              ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                              ▐                Shuffling Bingo Numbers!             ▌");
                System.out.println(
                                "                                                              ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                promptUser2(
                                ANSI_GREEN + "                                                                            Type < go > to continue:"
                                                + ANSI_ORANGE);
                System.out.println("\n");
                printBingoValues(shuffledBingoValues);
                System.out.println("\n");
                System.out.println(ANSI_GREEN +
                                "                                                               Print again to determine if there's a duplicate value.");
                promptUser2(
                                "                                                                            Type < go > to display:"
                                                + ANSI_ORANGE);
                printBingoValues(shuffledBingoValues);
                System.out.println("\n");
                System.out.println(ANSI_GREEN +
                                "                                                                      Type < go > to generate the Bingo Cards!"
                                + ANSI_YELLOW);
                promptUser2("");
                System.out.println("\n");

                String winner = "";
                while (winner.equals("")) {
                        for (BINGGO_BY_ROW
                 game : allGames) {
                                game.printBingoCard(); // Print each Bingo card

                        }

                        System.out.println(ANSI_YELLOW);
                        System.out.println("");
                        System.out.println("");
                        System.out.println(
                                        "                                                                     ████████                        ████████   ");
                        System.out.println(
                                        "                                                                    ███    ████████████████████████████    ███    ");
                        System.out.println(
                                        "                                                                    ██                                      ██ ");
                        System.out.println(
                                        "                                                                    ██          Press Enter to draw         ██ ");
                        System.out.println(
                                        "                                                                    ██            the next number:          ██ ");

                        System.out.println(
                                        "                                                                  ████                                      ████  ");
                        System.out.println(
                                        "                                                                 ███████                                  ███████  ");
                        System.out.println(
                                        "                                                                 ███  ██████████████████████████████████████  ███ ");
                        System.out.println(
                                        "                                                                  ███    ██       ██████████████       ██    ███  ");
                        System.out.println(
                                        "                                                                    ██    ███  ████            ████   ██    ██ ");
                        System.out.println(
                                        "                                                                     ███   █████                  ████    ███ ");
                        System.out.println(
                                        "                                                                       ██            ██    ██            ██  ");
                        System.out.println(
                                        "                                                                         ██                            ██  ");
                        System.out.println(
                                        "                                                                    ██  ██     ███            ███       ██  ");
                        System.out.println(
                                        "                                                                 ██████  ██        ████████████        ██   ");
                        System.out.println(
                                        "                                                                  ██       ██                        ██      ██  ");
                        System.out.println(
                                        "                                                                     ███     ███                  ███      █████  ");
                        System.out.println(
                                        "                                                                                ████          ████         ██   ");
                        System.out.println(
                                        "                                                                                    ██  ██  ██           ");
                        System.out.println(
                                        "                                                                                     █  ██  █   ");
                        System.out.println(
                                        "                                                                                     █  ██  █   ");
                        System.out.println(
                                        "                                                                                     █  ██  █   ");
                        System.out.println(
                                        "                                                                                     █  ██  █   ");
                        System.out.println(
                                        "                                                                             █████████  ██  █████████  ");
                        System.out.println(
                                        "                                                                           ███          ██          ███ ");
                        System.out.println(
                                        "                                                                           ██           ██           ██  ");
                        System.out.println(
                                        "                                                                           ███       ███  ███       ███ ");
                        System.out.println(
                                        "                                                                               █████          █████   ");
                        scanner.nextLine();
                        callNextNumber();

                        int calledNumber = dequeue();
                        if (calledNumber != -1) {
                                System.out.println(ANSI_YELLOW +
                                                "                                                                        Dequeuing number: "
                                                + calledNumber);
                                System.out.println("");
                                // You can use the dequeued number here for any specific functionality
                        }
                        winner = checkWinningPatterns();
                        printNaCallNa();
                }

                // Display the winner
                if (winner.equals("Full House")) {
                        System.out.println("Bingo! Full House Detected!");
                } else {
                        System.out.println("");
                        System.out.println("");
                        System.out.println(ANSI_GOLD +
                                        "                                                                                                                               █       ");
                        System.out.println(
                                        "                                                      ██   ███                                                            █   ████    ");
                        System.out.println(
                                        "                                                     ████                     ██████    ██████         ██████     "
                                                        + ANSI_GOLD + "       █████  ██  ");
                        System.out.println(
                                        "                                                      ██   █           █        ██████    ███       ██████████       "
                                                        + ANSI_GOLD + "    ██   █    ");
                        System.out.println(
                                        "                                                      ██           ██████       ████ ██   ███      █████  █████               ");
                        System.out.println(
                                        "                                                                 ███████         ███ ██   ███     █████   ██████  ");
                        System.out.println(
                                        "                                                                    ████         ███  ██  ███    ████    ");
                        System.out.println(
                                        "                                   █████                             ████        ███   ██████     ███   █████           ████          "
                                                        + ANSI_GOLD + "          ████  ");
                        System.out.println(
                                        "                                   ████████            ██████         ████       ████    ████     ████    █████     ███████████       "
                                                        + ANSI_GOLD + "    ██████████     ");
                        System.out.println(
                                        "                                      ████████       █████████         █████   ███████     ██       █████████     █████     ████   "
                                                        + ANSI_GOLD + "   ███████████  ");
                        System.out.println(
                                        "                                        ███████    ████    █████       ██████                         ██████    █████        ███  "
                                                        + ANSI_GOLD + "  █████████   ");
                        System.out.println(
                                        "                                           ████    █████  █████████   ████████             ███                 █████        █████  "
                                                        + ANSI_GOLD + "  ████      ");
                        System.out.println(
                                        "                                                      ██████    ████                     ██ ██                   ████      █████      ");
                        System.out.println(
                                        "                                                        █████  █████     ███                            ███      ████   ██████   ");
                        System.out.println(
                                        "                                                          ████████     █████    ██████████████████████  █████       ████████   ");
                        System.out.println(
                                        "                                                          █████       █████    ████████████████████████  █████    ");
                        System.out.println(ANSI_GOLD +
                                        "                                 ██████████                ██     ███ ████████████████████████████████████████ ███                   ██████████████   ");
                        System.out.println(
                                        "                                 ███████████      █   ██          ████ ████ █  ███████████████████████████████████           █   █   ██████████████      ");
                        System.out.println(
                                        "                                  ██████████    █████             ███████████  ████████████████████████ ███████████       ███████      ");
                        System.out.println(
                                        "                                                █████             ██████████    ██████████████████████   █████████  ██      ███    █    ");
                        System.out.println(
                                        "                                                  █    ███    ████ ██████████   ██████████████████████  ██████ ███████       █    ███   ");
                        System.out.println(
                                        "                                                               █████████████     █████████████████████   ████████████   ");
                        System.out.println(
                                        "                                        ██████                  █████████████    ████████████████████    ███████████                ████   ");
                        System.out.println(
                                        "                                    ██████████  " + ANSI_RESET + "  ██      "
                                                        + ANSI_GOLD
                                                        + "        ████████████    ███████████████████   ███████████                 ███████   ");
                        System.out.println(
                                        "                                  █████████    " + ANSI_RESET + "  ████     "
                                                        + ANSI_GOLD
                                                        + "   ███████████████ ███  ██████████████████  ██████████████████  "
                                                        + ANSI_RESET + "     ██ " + ANSI_GOLD + " █████████    ");
                        System.out.println(
                                        "                                   ████    " + ANSI_RESET + "    ████    "
                                                        + ANSI_GOLD
                                                        + "      ████████████████  █████████████████████████ █████████████      "
                                                        + ANSI_RESET + "     ████ " + ANSI_GOLD + "  ████████    ");
                        System.out.println(
                                        "                                        " + ANSI_RESET + "      ████      "
                                                        + ANSI_GOLD
                                                        + "       ██████████████ ██ ████████████████████ ██ ███████████       "
                                                        + ANSI_RESET + "      ████ " + ANSI_GOLD + "   █████     ");
                        System.out.println(
                                        "                               " + ANSI_ORANGE + "     ███   " + ANSI_RESET
                                                        + "   ███            " + ANSI_GOLD
                                                        + "      ███████████████  ████████████████  ███████████████          "
                                                        + ANSI_RESET + "      ███    ");
                        System.out.println(
                                        "                             " + ANSI_ORANGE + "      ███████" + ANSI_RESET
                                                        + " ███           ██    " + ANSI_GOLD
                                                        + "  ████████████████    ████████████  ████████████████████        "
                                                        + ANSI_RESET + "      ███  " + ANSI_ORANGE + "   ███  ");
                        System.out.println(
                                        "                              " + ANSI_ORANGE + "     ██  █████  " + ANSI_RESET
                                                        + "       ███████  " + ANSI_GOLD
                                                        + " █████████████████████   █████████  ███████████████████   "
                                                        + ANSI_RESET + "  ████          ██ " + ANSI_ORANGE
                                                        + " ██████ ");
                        System.out.println(
                                        "                              " + ANSI_ORANGE + "    ███   ████    "
                                                        + ANSI_RESET + "  █████        " + ANSI_GOLD
                                                        + "  ████████████████████   ██████   ████ ████████           "
                                                        + ANSI_RESET + "  ███████       " + ANSI_ORANGE
                                                        + " ███   ██  ");
                        System.out.println(
                                        "                              " + ANSI_ORANGE + "  ██████ █ █ ██ " + ANSI_RESET
                                                        + "████                " + ANSI_GOLD
                                                        + "     ███████████████  █████    ████████████████            "
                                                        + ANSI_RESET + "   ██████  " + ANSI_ORANGE + " ███    ███    ");
                        System.out.println(
                                        "                             " + ANSI_ORANGE
                                                        + "  ████████████ ██                    " + ANSI_GOLD
                                                        + "   ██████████████████ ██████  ███████████████████                    "
                                                        + ANSI_ORANGE + " ███ █████████  ");
                        System.out.println(
                                        "                         " + ANSI_ORANGE
                                                        + "   ██████████████ █ ██                " + ANSI_GOLD
                                                        + "    █████████  ████████████████████████████  ██████                    "
                                                        + ANSI_ORANGE + " ███ ███████████  ");
                        System.out.println(
                                        "                        " + ANSI_ORANGE + " ████████████████   ███ "
                                                        + ANSI_RESET + "██████████████    " + ANSI_GOLD
                                                        + "          ████████   ████████    ██████████         "
                                                        + ANSI_RESET + "   ████████     " + ANSI_ORANGE
                                                        + " ██   █████████████  ");
                        System.out.println(
                                        "                      " + ANSI_ORANGE + "  ██████████████████   ███"
                                                        + ANSI_RESET + " █████████████    " + ANSI_GOLD
                                                        + "        ████████    ██████████       █████          "
                                                        + ANSI_RESET + "  ████         " + ANSI_ORANGE
                                                        + " ███  █████████████████  ");
                        System.out.println(
                                        "                      " + ANSI_ORANGE + "  ████████████████████████          "
                                                        + ANSI_GOLD
                                                        + "        █   █             ██████████████                ██  ██              "
                                                        + ANSI_ORANGE + " █████████████████████ ");
                        System.out.println(
                                        "                      " + ANSI_ORANGE + "   █████████         ████           "
                                                        + ANSI_GOLD
                                                        + "      █     █           ██████████████████            ██    ██               "
                                                        + ANSI_ORANGE + " ██        █████████    ");
                        System.out.println(
                                        "                        " + ANSI_ORANGE + "   ███████                         "
                                                        + ANSI_GOLD
                                                        + "   █████               ███████████████████          █████                    "
                                                        + ANSI_ORANGE + "          █████   ");
                        System.out.println(
                                        "                         " + ANSI_ORANGE + "     █████                        "
                                                        + ANSI_GOLD
                                                        + "     █   █             ██████████████████             █   █                    "
                                                        + ANSI_ORANGE + "       █████  ");
                        System.out.println(
                                        "                            " + ANSI_ORANGE
                                                        + "   █████                                                                                                        "
                                                        + ANSI_ORANGE + "     ████     " + ANSI_GREEN);

                        System.out.println(
                                        "                                                       ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                        System.out.println(
                                        "                                                                   Bingo! Winning Pattern Detected on "
                                                        + winner + "'s Card!    ");
                        System.out.println(
                                        "                                                       ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                        System.out.println("");
                }

                // Display the winning card
                displayWinningCard(winner);
        }

        private static void promptUser(String text) {
                Scanner in = new Scanner(System.in);
                boolean isNotValid = true;
                while (isNotValid) {
                        System.out.print(
                                        "\n" + text
                                                        + "\n                                                                                    >>> ");

                        String key = in.next();
                        if (key.equals("yes")) {
                                isNotValid = false;
                        } else {
                                System.out.println("Incorrect input!");
                        }
                }
        }

        private static void promptUser2(String text) {
                Scanner in = new Scanner(System.in);
                boolean isNotValid = true;
                while (isNotValid) {
                        System.out.print("\n" + text + " ");
                        String key = in.next();
                        if (key.equals("go")) {
                                isNotValid = false;
                        } else {
                                System.out.println("Incorrect input!");
                        }
                }
        }

        private static void displayWinningCard(String winner) {
                System.out.println(
                                "                                                              ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                                                              ▐             Displaying the Winning Card...          ▌");
                System.out.println(
                                "                                                              ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                System.out.println("");
                for (BINGGO_BY_ROW
         game : allGames) {
                        if (game.cardIdentifier.equals(winner)) {
                                game.printBingoCard();

                                System.out.println(
                                                "                                                              ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                System.out.println(
                                                "                                                              ▐        Numbers called throughout the game...        ▌");
                                System.out.println(
                                                "                                                              ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                                System.out.println("\n");
                                System.out.print(
                                                "                                              ");
                                for (Integer n : naCallNaNumber) {
                                        System.out.print(n + " ");
                                }

                                break;
                        }
                }
        }

        private static void markOffNumber(int number) {

                for (BINGGO_BY_ROW
         game : allGames) {
                        for (int i = 0; i < ROWS; i++) {
                                for (int j = 0; j < COLUMNS; j++) {
                                        if (game.bingoCard[i][j] == number) {
                                                game.bingoCard[i][j] = 0; // Mark as called
                                        }
                                }
                        }
                }
        }

        private static void callNextNumber() {
                if (nextNumberIndex >= shuffledBingoValues.length * shuffledBingoValues[0].length) {
                        System.out.println("All numbers called!");
                        return;
                }

                String value = shuffledBingoValues[nextNumberIndex / COLUMNS][nextNumberIndex % COLUMNS].strip();
                //nadagdag---------------------------------------------------------
                shuffledBingoValues[nextNumberIndex/ COLUMNS][nextNumberIndex % COLUMNS] = "\u001B[31mX\u001B[0m".strip();
                //-------------------------------------------------------------------
                int nextNumber = Integer.parseInt(value);
                naCallNaNumber.add(nextNumber);

                String letter = getLetterForNumber(nextNumber);
                System.out.println(
                                "                                                                        Next Number: "
                                                + letter + " -> " + nextNumber);
                markOffNumber(nextNumber); // Mark off the number on all cards and shuffled values
                enqueue(nextNumber); // Add to the queue

                nextNumberIndex++;
        }

        private static void enqueue(int number) {
                numberQueue.add(number);
        }

        private static int dequeue() {
                if (numberQueue.isEmpty()) {
                        System.out.println("Queue is empty");
                        return -1;
                } else {
                        return numberQueue.remove(0);
                }
        }
}
