//package MIDTERM;

import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Scanner;

class Customer {
        private String name;
        private double balance;
        private LocalTime arrivalTime;
        private LocalTime transactionStartTime;
        private LocalTime transactionEndTime;
        public static void sleepForSeconds(int seconds) {
                try {
                    Thread.sleep(seconds * 1000); // Convert seconds to milliseconds
                } catch (InterruptedException e) {
                    // Handle interrupted exception
                    e.printStackTrace();
                }
            }

        public Customer(String name, double balance) {
                this.name = name;
                this.balance = balance;
        }

        public String getName() {
                return name;
        }

        public double getBalance() {
                return balance;
        }

        public void setArrivalTime(LocalTime arrivalTime) {
                this.arrivalTime = arrivalTime;
        }

        public LocalTime getArrivalTime() {
                return arrivalTime;
        }

        public void setTransactionStartTime(LocalTime transactionStartTime) {
                this.transactionStartTime = transactionStartTime;
        }

        public LocalTime getTransactionStartTime() {
                return transactionStartTime;
        }

        public void setTransactionEndTime(LocalTime transactionEndTime) {
                this.transactionEndTime = transactionEndTime;
        }

        public LocalTime getTransactionEndTime() {
                return transactionEndTime;
        }

        public void deposit(double amount) {
                if (amount <= 0) {
                        sleepForSeconds(1);
                        System.out.println(
                                        "                                                     ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                        System.out.println(
                                        "                                                     ▐                Invalid deposit amount.              ▌");
                        System.out.println(
                                        "                                                     ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                        return;
                }
                balance += amount;
                System.out.println(
                                "                            ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                            ▐                      Successfully deposited Php "
                                                + String.format("%.2f", amount) +
                                                ". New balance: Php " + String.format("%.2f", balance)
                                                + "                   ▌");
                System.out.println(
                                "                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
        }

        public void withdraw(double amount) {
                if (amount <= 0) {
                        sleepForSeconds(1);
                        System.out.println(
                                        "                                                     ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                        System.out.println(
                                        "                                                     ▐               Invalid withdrawal amount.            ▌");
                        System.out.println(
                                        "                                                     ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                        System.out.println("");
                        return;
                }
                if (balance < amount) {
                        sleepForSeconds(1);
                        System.out.println(
                                        "                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                        System.out.println(
                                        "                                  ▐              Insufficient funds. Cannot withdraw Php "
                                                        + String.format("%.2f", amount) + "                        ▌");
                        System.out.println(
                                        "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                        System.out.println("");
                        return;
                }
                balance -= amount;
                sleepForSeconds(1);
                System.out.println(
                                "                            ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                            ▐                      Successfully withdraw Php "
                                                + String.format("%.2f", amount) +
                                                ". New balance: Php " + String.format("%.2f", balance)
                                                + "                   ▌");
                System.out.println(
                                "                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
        }

        public void checkBalance() {
                sleepForSeconds(1);
                System.out.println(
                                "                            ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                System.out.println(
                                "                            ▐                                  Current balance for "
                                                + name
                                                + ": Php "
                                                + String.format("%.2f", balance)
                                                + "                             ▌");
                System.out.println(
                                "                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
        }

        public double getTransactionTimeSeconds() {
                if (transactionStartTime == null || transactionEndTime == null) {
                        return 0;
                }
                Duration duration = Duration.between(transactionStartTime, transactionEndTime);
                return duration.getSeconds();
        }

        public long getSecondsInQueue() {
                if (arrivalTime == null) {
                        return 0;
                }

                LocalTime now = LocalTime.now();
                if (transactionStartTime != null) {
                        now = transactionStartTime;
                }

                Duration duration = Duration.between(arrivalTime, now);
                return duration.getSeconds();
        }
}

public class AtTheMoment1 {

        public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);
                Queue<Customer> queue = new ArrayDeque<>();
                String redColor = "\u001B[31m";
                String blueColor = "\u001B[34m";
                String yellowColor = "\u001B[33m";
                String greenColor = "\u001B[32m";
                
                // Reset ANSI escape code
                String resetColor = "\u001B[0m";

                System.out.println(blueColor +
                                "█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████");
                System.out.println(
                                "█                                                                                                                                                       █");
                System.out.println(
                                "█                                                  "+redColor+"╔═╗┌┬┐  ╔╦╗┬ ┬┌─┐  ╔╦╗┌─┐┌┬┐┌─┐┌┐┌┌┬┐  ╔╗ ┌─┐┌┐┌┬┌─ "+blueColor+"                                                 █");
                System.out.println(
                        "█                                                  "+redColor+"╠═╣ │    ║ ├─┤├┤   ║║║│ ││││├┤ │││ │   ╠╩╗├─┤│││├┴┐"+blueColor+"                                                  █");
                System.out.println(
                        "█                                                  "+redColor+"╩ ╩ ┴    ╩ ┴ ┴└─┘  ╩ ╩└─┘┴ ┴└─┘┘└┘ ┴   ╚═╝┴ ┴┘└┘┴ ┴"+blueColor+"                                                  █");
                System.out.println(
                        "██▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄██");
                System.out.println(
                                "█                                                                                                                                                       █");
                while (true) {
                        System.out.println(
                                blueColor +"█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████");
                        System.out.println(
                                        "█                                                                                                                                                       █");
                        System.out.println(
                                        "█                                                                     "+yellowColor+"Customers in Queue:"+blueColor+"                                                               █");
                        System.out.println(
                                        "█                                                                                                                                                       █");
                        for (Customer customer : queue) {
                                System.out.println(
                                        yellowColor+"█                                                            - "
                                                                + customer.getName() + " (Time in Queue: "
                                                                + customer.getSecondsInQueue() + " seconds)" 
                                                                + "                                                         █"+blueColor); // sa
                                                                                                                                 // queue
                                                                                                                                 // first
                                                                                                                                 // 9seconds
                                                                                                                                 // hindi
                                                                                                                                 // mapantay
                                                                                                                                 // ASCII
                                                                                                                                 // pero
                                                                                                                                 // pag
                                                                                                                                 // nag
                                                                                                                                 // 10
                                                                                                                                 // above
                                                                                                                                 // na
                                                                                                                                 // okay
                                                                                                                                 // na
                                                                                                                                 // 'to!
                        }
                        System.out.println(
                                        "█                                                                                                                                                       █");

                        System.out.println(
                                        "█                                                                      "+greenColor+"Select an option:"+blueColor+"                                                                █");
                        System.out.println(
                                        "█                                                                                                                                                       █");
                        System.out.println(
                                        "█                                 "+greenColor+"█████████████████████████████                                █████████████████████████████"+blueColor+"                            █");
                        System.out.println(
                                        "█                                 "+greenColor+"█                           █                                █                           █"+blueColor+"                            █");
                        System.out.println(
                                        "█                                 "+greenColor+"█          Enqueue          █                                █          Process          █"+blueColor+"                            █");
                        System.out.println(
                                        "█                                 "+greenColor+"█       (Join Queue)        █                                █        Transaction        █"+blueColor+"                            █");
                        System.out.println(
                                        "█                                 "+greenColor+"█            <1>            █                                █            <2>            █"+blueColor+"                            █");
                        System.out.println(
                                        "█                                "+greenColor+" █                           █                                █                           █"+blueColor+"                            █");
                        System.out.println(
                                        "█                                 "+greenColor+"█████████████████████████████                                █████████████████████████████"+blueColor+"                            █");
                        System.out.println(
                                        "█                                                                                                                                                       █");
                        System.out.println(
                                        "█                                                                                                                                                       █");
                        System.out.println(
                                        "█                                                                                                                                                       █");
                        System.out.println(
                                        "█                                                        "+redColor+"███████████████████████████████████████████"+blueColor+"                                                    █");
                        System.out.println(
                                        "█                                                        "+redColor+"█                                         █"+blueColor+"                                                    █");
                        System.out.println(
                                        "█                                                        "+redColor+"█                 Terminate               █"+blueColor+"                                                    █");
                        System.out.println(
                                        "█                                                        "+redColor+"█                    <3>                  █"+blueColor+"                                                    █");
                        System.out.println(
                                        "█                                                        "+redColor+"█                                         █"+blueColor+"                                                    █");
                        System.out.println(
                                        "█                                                        "+redColor+"███████████████████████████████████████████"+blueColor+"                                                    █");
                        System.out.println(
                                        "█                                                                                                                                                       █");
                        System.out.println(
                                        "█                                                                                                                                                       █");
                        System.out.println(
                                        "██▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄██");

                        int choice = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        switch (choice) {
                                case 1:
                                        if (queue.size() >= 10) {
                                                System.out.println(
                                                        redColor+"                                                     ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                System.out.println(
                                                                "                                                     ▐     Queue is full. Cannot enqueue more customer.    ▌");
                                                System.out.println(
                                                                "                                                     ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                        } else {
                                                System.out.println(
                                                                "                                                                     Enter customer name:"); // 4
                                                                                                                                                              // leters
                                                                                                                                                              // na
                                                                                                                                                              // name
                                                                                                                                                              // lang
                                                                                                                                                              // ilagay
                                                                                                                                                              // para
                                                                                                                                                              // hindi
                                                                                                                                                              // masira
                                                                                                                                                              // ASCII,
                                                                                                                                                              // EX.
                                                                                                                                                              // Niel,
                                                                                                                                                              // Norn
                                                                                                                                                              // etc
                                                String customerName = scanner.nextLine();
                                                double balance = 1000 + Math.random() * 9000; // Random balance between
                                                // 1000 and 9999
                                                Customer newCustomer = new Customer(customerName, balance);
                                                LocalTime arrivalTime = LocalTime.now();
                                                sleepForSeconds(1);
                                                newCustomer.setArrivalTime(arrivalTime);
                                                sleepForSeconds(1);
                                                queue.offer(newCustomer);
                                                sleepForSeconds(1);
                                                System.out.println(
                                                                "                                ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                System.out.println(
                                                                "                                ▐            "
                                                                                + customerName
                                                                                + " has arrived and joined the queue with balance: Php "
                                                                                + String.format("%.2f", balance)
                                                                                + "           ▌"
                                                                                + " \n                                ▐                                     (Arrival Time:"
                                                                                + arrivalTime.toString().substring(0, 8)
                                                                                + ")" + "                          ▌");
                                                System.out.println(
                                                                "                                ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                                                System.out.println("\n\n");

                                        }
                                        break;
                                case 2:
                                        if (queue.isEmpty()) {
                                                sleepForSeconds(1);
                                                System.out.println(
                                                                redColor+"                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                System.out.println(
                                                                "                                  ▐                                   No customer in queue!                             ▌");
                                                System.out.println(
                                                                "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                System.out.println("");
                                        } else {
                                                Customer currentCustomer = queue.peek();
                                                System.out.println("");
                                                sleepForSeconds(1);
                                                System.out.println(
                                                                yellowColor+"                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                System.out.println(
                                                                "                                  ▐                            Processing transaction for "
                                                                                + currentCustomer.getName() + ":"
                                                                                + "                          ▌");
                                                System.out.println(
                                                                "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                System.out.println("");
                                                sleepForSeconds(1);
                                                System.out.println(yellowColor+
                                                                "                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                System.out.println(
                                                                "                                  ▐                Time in queue before transaction of "
                                                                                + currentCustomer.getName() + " is "
                                                                                + currentCustomer.getSecondsInQueue()
                                                                                + " seconds."
                                                                                + "               ▌");
                                                System.out.println(
                                                                "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                System.out.println("\n\n");
                                                sleepForSeconds(1);
                                                System.out.println(
                                                                blueColor+"▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");

                                                System.out.println(
                                                                "▐                                                                "+yellowColor+"Current balance: Php " +blueColor
                                                                                + String.format("%.2f",
                                                                                                currentCustomer.getBalance())
                                                                                + "                                                           ▌");
                                                System.out.println(
                                                                "▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                                                                sleepForSeconds(1);
                                                                System.out.println(
                                                                "▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                System.out.println(
                                                                "▐                                                                  "+yellowColor+"Select transaction type:"+blueColor+"                                                             ▌");
                                                System.out.println(
                                                                "▐                                                                                                                                                       ▌");
                                                System.out.println(
                                                                "▐               "+greenColor+"█████████████████████████████                   █████████████████████████████                  █████████████████████████████"+blueColor+"            ▌");
                                                System.out.println(
                                                                "▐               "+greenColor+"█                           █                   █                           █                  █                           █"+blueColor+"            ▌");
                                                System.out.println(
                                                                "▐               "+greenColor+"█          DEPOSIT          █                   █          WITHDRAW         █                  █          BALANCE          █"+blueColor+"            ▌");
                                                System.out.println(
                                                                "▐               "+greenColor+"█            <1>            █                   █            <2>            █                  █            <3>            █"+blueColor+"            ▌");
                                                System.out.println(
                                                                "▐               "+greenColor+"█                           █                   █                           █                  █                           █"+blueColor+"            ▌");
                                                System.out.println(
                                                                "▐               "+greenColor+"█████████████████████████████                   █████████████████████████████                  █████████████████████████████"+blueColor+"            ▌");
                                                System.out.println(
                                                                "▐                                                                                                                                                       ▌");
                                                System.out.println(
                                                                "▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");

                                                int transactionType = scanner.nextInt();
                                                scanner.nextLine(); // Consume newline

                                                switch (transactionType) {
                                                        case 1:
                                                        sleepForSeconds(1);
                                                                System.out.println(greenColor+
                                                                                "                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                                System.out.println(
                                                                                "                                  ▐                             Enter deposit amount for "
                                                                                                + currentCustomer
                                                                                                                .getName()
                                                                                                + ":"
                                                                                                + "                          ▌"); // Para
                                                                                                                                  // hindi
                                                                                                                                  // masira
                                                                                                                                  // ASCII
                                                                                                                                  // ,
                                                                                                                                  // ilagay
                                                                                                                                  // lang
                                                                                                                                  // na
                                                                                                                                  // number
                                                                                                                                  // na
                                                                                                                                  // idedeposit
                                                                                                                                  // ay
                                                                                                                                  // nasa
                                                                                                                                  // range
                                                                                                                                  // na
                                                                                                                                  // 100-999!
                                                                System.out.println(
                                                                                "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                                double depositAmount = scanner.nextDouble();
                                                                scanner.nextLine(); // Consume newline
                                                                currentCustomer.deposit(depositAmount);
                                                                currentCustomer.setTransactionStartTime(
                                                                                LocalTime.now());
                                                                break;
                                                        case 2:
                                                        sleepForSeconds(1);
                                                                System.out.println(
                                                                                greenColor+"▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                                System.out.println(
                                                                                "▐    Enter withdrawal amount for "
                                                                                                + currentCustomer
                                                                                                                .getName()
                                                                                                +
                                                                                                " (max: Php "
                                                                                                + String.format("%.2f",
                                                                                                                currentCustomer.getBalance())
                                                                                                + ")"
                                                                                                + "                                                                                                ▌"); // range
                                                                                                                                                                                                        // na
                                                                                                                                                                                                        // ilagay
                                                                                                                                                                                                        // ay
                                                                                                                                                                                                        // nasa
                                                                                                                                                                                                        // 1000
                                                                                                                                                                                                        // to
                                                                                                                                                                                                        // 9999,
                                                                                                                                                                                                        // para
                                                                                                                                                                                                        // hindi
                                                                                                                                                                                                        // masira
                                                                                                                                                                                                        // ASCII
                                                                System.out.println(
                                                                                "▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                                double withdrawAmount = scanner.nextDouble();
                                                                scanner.nextLine(); // Consume newline
                                                                currentCustomer.withdraw(withdrawAmount);
                                                                currentCustomer.setTransactionEndTime(LocalTime.now());
                                                                break;
                                                        case 3:
                                                        sleepForSeconds(1);
                                                                currentCustomer.checkBalance();
                                                                break;
                                                        default:
                                                        sleepForSeconds(1);
                                                                System.out.println(redColor+
                                                                                "                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                                System.out.println(
                                                                                "                                  ▐                                  Invalid transaction type                           ▌");
                                                                System.out.println(

                                                                                "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                }
                                                System.out.println("\n");
                                                sleepForSeconds(1);
                                                System.out.println(yellowColor+
                                                                "                                                     ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                System.out.println(
                                                                "                                                     ▐      Time in using the ATM by "
                                                                                + currentCustomer.getName() + " is: "
                                                                                + currentCustomer.getSecondsInQueue()
                                                                                + " seconds." + "  ▌");
                                                System.out.println(
                                                                "                                                     ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                System.out.println("\n");
                                                sleepForSeconds(1);
                                                System.out.println(yellowColor +
                                                                "                            ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                System.out.println(
                                                                "                            ▐                           Would you like to do another transaction? (yes/no)                       ▌");
                                                System.out.println(
                                                                "                            ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                String continueChoice = scanner.nextLine();
                                                System.out.println("\n");
                                                if (continueChoice.equalsIgnoreCase("no")) {
                                                        queue.poll(); // Remove customer from queue
                                                        sleepForSeconds(1);
                                                        System.out.println(greenColor+
                                                                        "                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                        System.out.println(
                                                                        "                                  ▐                           Thank you for using the ATM. Goodbye!                     ▌");
                                                        System.out.println(
                                                                        "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌");
                                                        System.out.println("\n");
                                                        sleepForSeconds(1);
                                                        System.out.println(

                                                                        "                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                        System.out.println(
                                                                        "                                  ▐                            "
                                                                                        + currentCustomer.getName()
                                                                                        + " has been removed to the queue                       ▌");
                                                        System.out.println(
                                                                        "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                        System.out.println("\n");
                                                        sleepForSeconds(1);
                                                        // Simulate ATM usage time
                                                        backMainMernu(choice);
                                                        
                                                } else {
                                                        sleepForSeconds(1);
                                                        System.out.println(yellowColor+
                                                                        "                                                     ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                                        System.out.println(
                                                                        "                                                     ▐                 Returning to main menu.             ▌");
                                                        System.out.println(
                                                                        "                                                     ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                                }
                                        }
                                        break;
                                case 3:
                                sleepForSeconds(1);
                                        System.out.println(redColor+
                                                        "                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                        System.out.println(
                                                        "                                  ▐                        Terminating the At The Moment Bank. Goodbye!                 ▌");
                                        System.out.println(
                                                        "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                                        System.exit(0);
                                        
                                default:
                                sleepForSeconds(1);
                                        System.out.println(redColor+
                                                        "                                  ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                                        System.out.println(
                                                        "                                  ▐                             Invalid option. Please try again.                       ▌");
                                        System.out.println(
                                                        "                                  ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                        }
                }
        }

        private static void backMainMernu(int time) {
                String redColor = "\u001B[31m";
                String blueColor = "\u001B[34m";
                String yellowColor = "\u001B[33m";
                String greenColor = "\u001B[32m";
                
                // Reset ANSI escape code
                String resetColor = "\u001B[0m";
                try {
                        System.out.println(yellowColor+
                                        "                                                     ▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌");
                        System.out.println(
                                        "                                                     ▐                     Going back...                   ▌");
                        System.out.println(
                                        "                                                     ▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌"+resetColor);
                        System.out.println("\n");
                        Thread.sleep(time);
                } catch (InterruptedException e) {
                        e.printStackTrace();
                }
        }
        public static void sleepForSeconds(int seconds) {
                try {
                    Thread.sleep(seconds * 1000); // Convert seconds to milliseconds
                } catch (InterruptedException e) {
                    // Handle interrupted exception
                    e.printStackTrace();
                }
            }
}
