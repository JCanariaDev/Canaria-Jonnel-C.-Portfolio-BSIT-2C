import java.util.Random;
import java.util.Scanner;

public class Monkey_ni_JONNEL {
    public static void main(String[] args) {
        welcome();
        drawing();
        Random random = new Random();
        Scanner scan = new Scanner(System.in); 
        String[] decs_arr = decs_of_cards(); 

        //Display the welcoming message
        begin(decs_arr); 

        //Count the decs
        count_of_decs(decs_arr);
        System.out.println();

        //Randomly pick one card from the decs of card
        String card_pick = pick_one_cards(decs_arr, random); 
        String hidden_card = card_pick; 

        //Secret card ---------------
        System.out.println("Here is the random picked from the decs of cards");
        display_picked_first(card_pick);
        //Secret card --------------

        //Remove picked card in the decs of card
        String[] card_arr_final = removeOne_inCards(decs_arr, card_pick);
        System.out.println();

        //Shuffle the card
        System.out.println("Shuffling....................................................");
        String[] shuf_arr = shuffle(random, card_arr_final); 

        //Initialize the size of every player card array
        String[] human_cards = new String[17]; 
        String[] com1_cards = new String[17]; 
        String[] com2_cards = new String[17]; 
        System.out.println();

        //Randomly allocated for both players in tagalog pamahat or pamigay
        distributeCards(shuf_arr, human_cards, com1_cards, com2_cards, random);//The cards is from shuf_arr array 

        //Display the allocated card for both players in tagalog parang pinakita na sa console
        display_allocated_card_with_icon1(human_cards, com1_cards, com2_cards);

        //It is literally remove pair from each card and return remaining card
        String[] human_natitirang_card = removePair(human_cards); //It removes pairs from the card and return remaining card
        String[] com1_natitirang_card = removePair(com1_cards); //It removes pairs from the card and return remaining card
        String[] com2_natitirang_card = removePair(com2_cards); //It removes pairs from the card and return remaining card

        /*
        For no confusion i explain briefly, the removepair and return_pair_cards_for_players method is really important
        and really connected each other beacause the remove pair is responsible for removing pair and returning no pair card 
        and also the return_pair_cards_for_players is responsible for returning the pair card meaning in this situation the 
        removepair in real life is removing the pair of cards(hate or remove) and return_pair_cards_for_players is getting back
        the remove pair or pair card in removePair method.
        BASICALLY THE remove pair method is the data(pair cards) is out and in the return_pair_cards_for_players method is the data(pair cards) is
        IN or getting back, NOW YOU KNOW
        I PUT COMMENT BECAUSE I ALSO NALITO DIN PO SA PAGGAWA KO NG METHOD NATOH
        */

        //Display the pair card for each player 
        String[] human_pair = return_pair_cards_for_players(human_natitirang_card, human_cards);
        System.out.println();

        //System.out.println("Here is your pair cards com1");
        String[] com1_pair =  return_pair_cards_for_players(com1_natitirang_card, com1_cards);

        //System.out.println("Here is your pair cards com2");
        String[] com2_pair = return_pair_cards_for_players(com2_natitirang_card, com2_cards);

        display_pair_card_with_icon1(human_pair, com1_pair, com2_pair);
        System.out.println();

        //Display remaining of each player 
        display_remaining_card_with_icon1(human_natitirang_card, com1_natitirang_card, com2_natitirang_card);
        System.out.println();
        if (human_natitirang_card.length == 0){
            System.out.println("Human you win in this game!");
            System.out.println("Congrats"); 
        } else if (com1_natitirang_card.length == 0){
            System.out.println("Computer 1 you win in this game!");
            System.out.println("Congrats!");
        } else if (com2_natitirang_card.length == 0){
            System.out.println("Computer 2 you win in this game!");
            System.out.println("Congrats");
        }
        String[][] final_patira = new String[3][];
        String[] final_name_patira = new String[3]; 
        String[] winner = new String[2];
        int winner_cnt = 0;

        //Game loop
        boolean TRUE = true; 
        while (TRUE){ 
            if (winner_cnt == 2){//NO SENSE IF STATEMENT(ingnore it!)
                break;
            } else { //Real game loop
                //Human picked either head or tail
                String[] win_sec_third = toss_Coin_and_display_result(scan, random);//Index zero is the winner 
                display_placer(win_sec_third);
                System.out.println("Good luck "+win_sec_third[0]); //Index xero becuse the first index is second to play, and second index is third to play
                System.out.println("Please choose one card from the opponent card");

                //Patira array
                String[] name_patira = new String[3]; 
                String[][] patira = new String[3][17];
                if (win_sec_third[0].equalsIgnoreCase("Human")){
                    patira[0] = human_natitirang_card.clone(); 
                    name_patira[0] = "Human";
                } else if (win_sec_third[0].equalsIgnoreCase("Computer 1")){
                    patira[0] = com1_natitirang_card.clone(); 
                    name_patira[0] = "Computer 1"; 
                } else if (win_sec_third[0].equalsIgnoreCase("Computer 2")){
                    patira[0] = com2_natitirang_card.clone(); 
                    name_patira[0] = "Computer 2"; 
                }
                if (win_sec_third[1].equalsIgnoreCase("Human")){
                    patira[1] = human_natitirang_card.clone();
                    name_patira[1] = "Human"; 
                } else if (win_sec_third[1].equalsIgnoreCase("Computer 1")){
                    patira[1] = com1_natitirang_card.clone(); 
                    name_patira[1] = "Computer 1";
                } else if (win_sec_third[1].equalsIgnoreCase("Computer 2")){
                    patira[1] = com2_natitirang_card.clone(); 
                    name_patira[1] = "Computer 2"; 
                }
                if (win_sec_third[2].equalsIgnoreCase("Human")){
                    patira[2] = human_natitirang_card.clone(); 
                    name_patira[2] = "Human"; 
                } else if (win_sec_third[2].equalsIgnoreCase("Computer 1")){
                    patira[2] = com1_natitirang_card.clone(); 
                    name_patira[2] = "Computer 1";
                } else if (win_sec_third[2].equalsIgnoreCase("Computer 2")){
                    patira[2] = com2_natitirang_card.clone(); 
                    name_patira[2] = "Computer 2";
                }//index patira == 0
                //index kuhaan == 2
                //Initialize the counter 
                int counter_kuhaan = 1; 
                int counter_patira = 0;
                int two_draw = 0;
                boolean second_true = true;
                while (second_true) { 
                    if (patira[counter_patira].length == 0){ 
                        counter_patira++;
                        counter_patira %= 3;
                        counter_kuhaan %= 3;
                        counter_kuhaan = counter_kuhaan % 3; 
                        continue;
                    }
                    if (patira[counter_kuhaan].length == 0){
                        counter_kuhaan++; 
                        counter_patira %= 3;
                        counter_kuhaan %= 3;
                        continue;
                    }
                    if (patira[counter_patira] == patira[counter_kuhaan]){
                        counter_kuhaan++; 
                        counter_patira %= 3;
                        counter_kuhaan %= 3;
                        continue; 
                    }
                    System.out.println(name_patira[counter_patira] + " you can chance to get your pair card in " + name_patira[counter_kuhaan]);
                    int index_of_choose; 
                    System.out.println("Enter the position >>");
                    while (true) {
                        try {
                            String input = scan.nextLine();
                            if (input.trim().isEmpty()) {
                                throw new Exception("Empty input");
                            }
                            index_of_choose = Integer.parseInt(input);
                            if (index_of_choose > patira[counter_kuhaan].length){
                                System.out.println("Please enter a proper range!");
                                continue; 
                            }
                            if (index_of_choose < 1){
                                System.out.println("Please enter a proper range!");
                                continue; 
                            }
                            break;
                        } catch (NumberFormatException e) {
                            System.out.println("Please enter a valid integer for the position of the card.");
                        } catch (Exception e) {
                            System.out.println("Please enter the position of the card.");
                        }
                    }
                    
                    String picked_card = pick_one_card_in_opponent(patira[counter_kuhaan], index_of_choose);

                    String[] res = removeOne_inCards(patira[counter_kuhaan], picked_card);
                    patira[counter_kuhaan] = res;

                    patira[counter_patira] = add_one_in_the_current_player(patira[counter_patira], picked_card); 

                    System.out.println(name_patira[counter_patira]+" here is the value of your choosen card, the card is:");
                    display_picked_card(picked_card);
                    System.out.println();

                    String[] result = removePair(patira[counter_patira]);

                    System.out.println(name_patira[counter_patira]+" here is your pair cards");

                    String[] pair_card = display_pair_cards_for_player_loop(result, patira[counter_patira]); 
                    pair_card_loop(pair_card);                              
                    System.out.println();                     

                    patira[counter_patira] = result; 

                    //DEBUGGING ----------------------------------------------------------
                    display_remaining_card_with_icon1(patira[0], patira[1], patira[2],name_patira[0], name_patira[1], name_patira[2]);
                    System.out.println();
                    
                    //Declare the winner 
                    String already = checker_if_done(patira, name_patira, winner);
                    for(int i = 0; i < name_patira.length;i++){
                        if(already != null){
                            if(name_patira[i] == already){
                                winner[winner_cnt] =  already; 
                                winner_cnt++;
                            }
                        }
                    }
                    if (counter_patira == 2){
                        counter_patira = -1;
                    }
                    if (counter_kuhaan == 2){
                        counter_kuhaan = -1; 
                    }
                    counter_patira++; 
                    counter_kuhaan++;
                    for (int i = 0; i < patira.length; i++){
                        if (patira[i].length == 0){
                            two_draw++;
                        }
                    }
                    if (two_draw == 2) {
                        TRUE = false; //For Outer loop
                        second_true = false;//For Inner loop
                        final_patira = patira;
                        final_name_patira = name_patira; 
                    } else {
                        two_draw = 0;
                    }
                }
            }
            declare_monkey(losser(final_patira, final_name_patira), hidden_card);
        }
    }
    public static void declare_monkey(String[] losser, String hidden_card){
        check_hidden_last(hidden_card, losser[1], losser[0]);
    }
	public static void check_hidden_last(String hidden, String last_card, String name_of_the_last){
        String[] hidden_parts = hidden.split("_");
        String[] last_parts = last_card.split("_"); 
        String value_h = hidden_parts[1]; //Value of hidden
        String value_l = last_parts[1];  //Value of Last card of the losser

        String[] two_cards = {hidden, last_card};
        System.out.println("The hidden card and last card is ");
        System.out.println();
        hidden_and_last_card(two_cards);
        System.out.println();
        if (value_h.equals(value_l)){//Checks if the value of hidden card is same in value of last card of the player
            System.out.println("The hidden card and last card of the "+ name_of_the_last+" is Pair!");
            System.out.println(name_of_the_last+" you're the MONKEY!");
        } else {
            System.out.println("The hidden card and last card of the "+ name_of_the_last+" is Not Pair!");
            System.out.println(name_of_the_last+" you,re not a MONKEY!");
        }
        System.out.println();
    }
    public static String[] losser(String[][] patira, String[] name_patira){
        String[] name_and_cards = new String[2];
        for (int i = 0; i < patira.length; i++){
            if (patira[i].length == 1){
                name_and_cards[0] = name_patira[i]; //put the name of the losser 
                name_and_cards[1] = patira[i][0];   //put the one card of the losser 
                return name_and_cards; 
            }
        }
        return null;
    }
    public static String checker_if_done(String[][] patira, String[] name_patira, String[] winner){
        int len_of_winner = 0; 
        for (int w = 0; w < winner.length; w++){
            if (winner[w] != null){
                len_of_winner++; 
            }
        }
        for (int i = 0; i < patira.length; i++){
            if (patira[i].length == 0){
                boolean isNewWinner = true;
                for (int j = 0; j < len_of_winner; j++){
                    if (name_patira[i].equals(winner[j])){
                        isNewWinner = false;
                        break;
                    }
                }
                if (isNewWinner && len_of_winner == 0) {
                    System.out.println(name_patira[i] + " you win in this game!");
                    System.out.println("Congrats");
                    winner[len_of_winner] = name_patira[i]; 
                    return name_patira[i];
                }
            }
        }
        return null;
    }
    
    public static String[][] return_cheker_card(String[][] patira) {
        int size = 0;  
        // Determine the size of the new_patira array
        if (patira.length == 3) {
            size += (patira[0].length != 0) ? 1 : 0;
            size += (patira[1].length != 0) ? 1 : 0;
            size += (patira[2].length != 0) ? 1 : 0;
        } else if (patira.length == 2) {
            size += (patira[0].length != 0) ? 1 : 0;
            size += (patira[1].length != 0) ? 1 : 0;
        } else if (patira.length == 1) {
            size += (patira[0].length != 0) ? 1 : 0;
        }
        // Initialize the new_patira array with the determined size
        String[][] new_patira = new String[size][];
    
        // Fill the new_patira array with non-empty card arrays from patira
        int index = 0;
        for (String[] card : patira) {
            if (card.length != 0) {
                new_patira[index++] = card;
            }
        }
        return new_patira;
    }
    //Begin method
    public static void begin(String[] cards) {
        //Welcome
        System.out.println("Welcome to Monkey Monkey");
        System.out.println("HUMAN vs COMPUTER");
        //Display the card 
        System.out.println("Here is the decs of card");
        display_card_51(cards);
        System.out.println();
    }
    //Count the number of cards 
    public static void count_of_decs(String[] decs_arr) {
        int num = decs_arr.length;        
        System.out.println("The number of cards is "+num); 
    }
    //Randomize/Pick 1 (one) card from the deck 
    public static String pick_one_cards(String[] decs_arr, Random random) {
        int picked_index = random.nextInt(52); 
        String cards_pick = decs_arr[picked_index]; 
        return cards_pick;  
    }
    public static void display_picked_first(String str){
        String[] parts = str.split("_");
        String suit = parts[0];
        String value = parts[1];
        int valueLength = value.length();    
        
        card_icon_picked_first(suit,value, valueLength); 
    }

    //Remove one card in the decs of card 
    public static String[] removeOne_inCards(String[] decs_arr, String card_pick){//DEBUGING--------------------------------------------not yet
        String[] prev_decs = decs_arr;
        String[] decs_arr_minus_1 = new String[decs_arr.length - 1]; // Create a new array with length one less than the original array
        if (decs_arr.length != 0){
            int index = 0; // Initialize index for the new array
            for (int i = 0; i < decs_arr.length; i++) {
                if (decs_arr[i].equals(card_pick)) { // If the current card matches the picked card
                    // Skip this card, effectively removing it from the new array
                    continue;
                }
                // Otherwise, add the current card to the new array
                decs_arr_minus_1[index++] = decs_arr[i];
            }
            return decs_arr_minus_1;    
        } else {
            return prev_decs;
        }
    }

    //Shuffle pra magulo ang buhay mo
    public static String[] shuffle(Random random, String[] decs_arr) {
        for (int i = decs_arr.length - 1; i  > 0; i--) {
            int index = random.nextInt(i); // Generate a random index between 0 and i
            // Swap array[i] with array[index]
            String temp = decs_arr[i];
            decs_arr[i] = decs_arr[index];
            decs_arr[index] = temp;
        }
        System.out.println("Here is the shuffle cards");
        System.out.println();
        String[] return_arr = new String[decs_arr.length];
        for (int i = 0; i < decs_arr.length; i++) {
            return_arr[i] = decs_arr[i];
        }
        display_shuffle(return_arr);
        return return_arr;
    }   

    //Alocate the cards sa tagalog pamahat or pamigay
    public static void distributeCards(String[] shuf_arr, String[] human_cards, String[] com1_cards, String[] com2_cards, Random random) {
        String[] shuffle_again = distribute_shuffle(random, shuf_arr); //Shuffle the existing shuffle array 
        int h = 0, c1 = 0, c2 = 0; //Counter 

        for (int i = 0; i < shuffle_again.length; i++) {
            String card = shuffle_again[i];
            if (card == null) continue; // Skip null cards(just for debugging purposes lang po kaya ako nag lagay neto)

            if (h < human_cards.length) {
                human_cards[h++] = card;
            } else if (c1 < com1_cards.length) {
                com1_cards[c1++] = card;
            } else if (c2 < com2_cards.length) {
                com2_cards[c2++] = card;
            }
        }
    }

    //Shuffle the shuffle array(FOR distributeCards method)
    public static String[] distribute_shuffle(Random random, String[] decs_arr) {
        for (int i = decs_arr.length - 1; i  > 0; i--) {
            int index = random.nextInt(i); // Generate a random index between 0 and i
            // Swap array[i] with array[index]
            String temp = decs_arr[i];
            decs_arr[i] = decs_arr[index];
            decs_arr[index] = temp;
        }
        String[] return_arr = new String[decs_arr.length];
        for (int i = 0; i < decs_arr.length; i++) {
            return_arr[i] = decs_arr[i];
        }
        return return_arr;
    } 
    

    public static void display_allocated_card_with_icon1(String[] human_card, String[] com1_card, String[] com2_card){
        String[][] three_player = {human_card, com1_card, com2_card};
        String[] name = {"Human", "Computer 1", "Computer 2"}; 
        for (int i = 0; i < three_player.length; i++){
            String[] suit = new String[three_player[i].length];
            String[] value = new String[three_player[i].length]; 
            int[] valueLength = new int[three_player[i].length];
            System.out.println(name[i]+" here is your card");
            for (int j = 0; j < three_player[i].length; j++) {
                String card = three_player[i][j];
                if (card == null) continue;
                String[] parts = card.split("_");
                suit[j] = parts[0];
                value[j] = parts[1];
                valueLength[j] = value[j].length();    
            } 
            display_allocated_card_with_icon2(suit, value, valueLength, three_player[i].length);
            System.out.println();
        }
    }

    public static void display_allocated_card_with_icon2(String[] suits, String[] values, int[] valueLength, int number_of_cards) {
        // Initialize the card icon lines outside the loop
        String horizontalLine = "  _________";
        String[] firstVerticalLines = new String[number_of_cards];
        String[] secondVerticalLines = new String[number_of_cards];
        String[] thirdVerticalLines = new String[number_of_cards];
        String bottomLine = " |_________|";
    
        // Construct the card icon lines for each card
        for (int i = 0; i < 11; i++) {
            firstVerticalLines[i] = String.format(" | %s       |", suits[i]);
            secondVerticalLines[i] = " |         |";
            thirdVerticalLines[i] = String.format(" |    %s|", values[i] + " ".repeat(Math.max(0, 5 - valueLength[i])));
        }
        //First row 
        // Print the card icons horizontally
        for (int i = 0; i < 11; i++) {
            // Print the concatenated strings for each line of the card icon
            System.out.print(horizontalLine + "  ");
        }
        System.out.println(); // Print a new line after printing all horizontal lines
    
        // Print the first vertical line for each card
        for (int i = 0; i < 11; i++) {
            System.out.print(firstVerticalLines[i] + " ");
        }
        System.out.println();
    
        // Print the second vertical line for each card
        for (int i = 0; i < 11; i++) {
            System.out.print(secondVerticalLines[i] + " ");
        }
        System.out.println();
    
        // Print the third vertical line with values for each card
        for (int i = 0; i < 11; i++) {
            System.out.print(thirdVerticalLines[i] + " ");
        }
        System.out.println();
    
        // Print the bottom line for each card
        for (int i = 0; i < 11; i++) {
            System.out.print(bottomLine + " ");
        }
        System.out.println();

        //Second row 
        for (int i = 11; i < 17; i++) {
            firstVerticalLines[i] = String.format(" | %s       |", suits[i]);
            secondVerticalLines[i] = " |         |";
            thirdVerticalLines[i] = String.format(" |    %s|", values[i] + " ".repeat(Math.max(0, 5 - valueLength[i])));
        }
        // Print the card icons horizontally
        for (int i = 11; i < 17; i++) {
            // Print the concatenated strings for each line of the card icon
            System.out.print(horizontalLine + "  ");
        }
        System.out.println(); // Print a new line after printing all horizontal lines
    
        // Print the first vertical line for each card
        for (int i = 11; i < 17; i++) {
            System.out.print(firstVerticalLines[i] + " ");
        }
        System.out.println();
    
        // Print the second vertical line for each card
        for (int i = 11; i < 17; i++) {
            System.out.print(secondVerticalLines[i] + " ");
        }
        System.out.println();
    
        // Print the third vertical line with values for each card
        for (int i = 11; i < 17; i++) {
            System.out.print(thirdVerticalLines[i] + " ");
        }
        System.out.println();
    
        // Print the bottom line for each card
        for (int i = 11; i < 17; i++) {
            System.out.print(bottomLine + " ");
        }
        System.out.println();
    }

    //Remove pair ito din mahirap din ito(remove pair of the cards)
    public static String[] removePair(String[] hand) {
        boolean[] removed = new boolean[hand.length];
        for (int i = 0; i < hand.length - 1; i++) {
            if (hand[i] == null || removed[i]) continue; // Skip null values and already removed cards
            for (int j = i + 1; j < hand.length; j++) {
                if (hand[j] == null || removed[j]) continue; // Skip null values and already removed cards
                if (isPair(hand[i], hand[j])) {
                    removed[i] = true;
                    removed[j] = true;
                    break; // Exit inner loop after finding a pair 
                }
            }
        }
        int newSize = 0;
        for (boolean isRemoved : removed) {
            if (!isRemoved) newSize++;
        }
        String[] result = new String[newSize];
        int index = 0;
        for (int i = 0; i < hand.length; i++) {
            if (!removed[i]) {
                result[index++] = hand[i];
            }
        }
        return result;
    }

    //Return array of pair card
    public static String[] return_pair_cards_for_players(String[] player_remove_pair, String[] player_cards_before_remove_pair) {
        int size_counter = 0;
        // Count the number of cards to be returned
        for (int i = 0; i < player_cards_before_remove_pair.length; i++) {
            if (player_cards_before_remove_pair[i] != null) { // Check for null values
                boolean found = false; // Flag to check if the card is removed
                for (int j = 0; j < player_remove_pair.length; j++) {
                    if (player_remove_pair[j] != null && player_cards_before_remove_pair[i].equals(player_remove_pair[j])) {
                        found = true; // Set found to true if the card is removed
                        break; // Exit inner loop if the card is found
                    }
                }
                if (!found) {
                    size_counter++; // Increment the counter for non-removed cards
                }
            }
        }
        // Initialize the return array with the correct size
        String[] return_arr = new String[size_counter];
        int index = 0;
    
        // Populate the return array with non-removed cards
        for (int i = 0; i < player_cards_before_remove_pair.length; i++) {
            if (player_cards_before_remove_pair[i] != null) { // Check for null values
                boolean found = false; // Flag to check if the card is removed
                for (int j = 0; j < player_remove_pair.length; j++) {
                    if (player_remove_pair[j] != null && player_cards_before_remove_pair[i].equals(player_remove_pair[j])) {
                        found = true; // Set found to true if the card is removed
                        break; // Exit inner loop if the card is found
                    }
                }
                if (!found) {
                    return_arr[index++] = player_cards_before_remove_pair[i]; // Assign the card to return_arr and increment index
                }
            }
        }
        System.out.println();
        return return_arr; 
    }

    public static void display_pair_card_with_icon1(String[] human_pair_card, String[] com1_pair_card, String[] com2_pair_card){
        String[][] three_player = {human_pair_card, com1_pair_card, com2_pair_card};
        String[] name = {"Human", "Com1", "Com2"}; 
        for (int i = 0; i < three_player.length; i++){
            String[] suit = new String[three_player[i].length];
            String[] value = new String[three_player[i].length]; 
            int[] valueLength = new int[three_player[i].length];
            System.out.println(name[i]+" here is pair card");
            for (int j = 0; j < three_player[i].length; j++) {
                String card = three_player[i][j];
                if (card == null) continue;
                String[] parts = card.split("_");
                suit[j] = parts[0];
                value[j] = parts[1];
                valueLength[j] = value[j].length();    
            } 
            display_pair_card_with_icon2(suit, value, valueLength, three_player[i].length);
            System.out.println();
        }
    }

    public static void display_pair_card_with_icon2(String[] suits, String[] values, int[] valueLength, int number_of_cards) {
        if (number_of_cards > 10){
            int first_row_size = Math.min(10, number_of_cards);
            //int second_row_size = number_of_cards - first_row_size;
            
            String horizontalLine = "  _________";
            String[] firstVerticalLines = new String[number_of_cards];
            String[] secondVerticalLines = new String[number_of_cards];
            String[] thirdVerticalLines = new String[number_of_cards];
            String bottomLine = " |_________|";
            
            // Construct the card icon lines for each card
            for (int i = 0; i < number_of_cards; i++) {
                firstVerticalLines[i] = String.format(" | %s       |", suits[i]);
                secondVerticalLines[i] = " |         |";
                thirdVerticalLines[i] = String.format(" |    %s|", values[i] + " ".repeat(Math.max(0, 5 - valueLength[i])));
            }     
            // First row 
            // Print the card icons horizontally
            for (int i = 0; i < first_row_size; i++) {
                // Print the concatenated strings for each line of the card icon
                System.out.print(horizontalLine + "  ");
            }
            System.out.println(); // Print a new line after printing all horizontal lines
            
            // Print the first vertical line for each card
            for (int i = 0; i < first_row_size; i++) {
                System.out.print(firstVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the second vertical line for each card
            for (int i = 0; i < first_row_size; i++) {
                System.out.print(secondVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the third vertical line with values for each card
            for (int i = 0; i < first_row_size; i++) {
                System.out.print(thirdVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the bottom line for each card
            for (int i = 0; i < first_row_size; i++) {
                System.out.print(bottomLine + " ");
            }
            System.out.println();
            
            // Second row 
            for (int i = first_row_size; i < number_of_cards; i++) {
                // Print the card icons horizontally for the second row
                System.out.print(horizontalLine + "  ");
            }
            System.out.println(); // Print a new line after printing all horizontal lines
            
            // Print the first vertical line for each card in the second row
            for (int i = first_row_size; i < number_of_cards; i++) {
                System.out.print(firstVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the second vertical line for each card in the second row
            for (int i = first_row_size; i < number_of_cards; i++) {
                System.out.print(secondVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the third vertical line with values for each card in the second row
            for (int i = first_row_size; i < number_of_cards; i++) {
                System.out.print(thirdVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the bottom line for each card in the second row
            for (int i = first_row_size; i < number_of_cards; i++) {
                System.out.print(bottomLine + " ");
            }
        } else {
            // Initialize the card icon lines outside the loop
            String horizontalLine = "  _________";
            String[] firstVerticalLines = new String[number_of_cards];
            String[] secondVerticalLines = new String[number_of_cards];
            String[] thirdVerticalLines = new String[number_of_cards];
            String bottomLine = " |_________|";
        
            // Construct the card icon lines for each card
            for (int i = 0; i < number_of_cards; i++) {
                firstVerticalLines[i] = String.format(" | %s       |", suits[i]);
                secondVerticalLines[i] = " |         |";
                thirdVerticalLines[i] = String.format(" |    %s|", values[i] + " ".repeat(Math.max(0, 5 - valueLength[i])));
            }
        
            // Print the card icons horizontally
            for (int i = 0; i < number_of_cards; i++) {
                // Print the concatenated strings for each line of the card icon
                System.out.print(horizontalLine + "  ");
            }
            System.out.println(); // Print a new line after printing all horizontal lines
        
            // Print the first vertical line for each card
            for (int i = 0; i < number_of_cards; i++) {
                System.out.print(firstVerticalLines[i] + " ");
            }
            System.out.println();
        
            // Print the second vertical line for each card
            for (int i = 0; i < number_of_cards; i++) {
                System.out.print(secondVerticalLines[i] + " ");
            }
            System.out.println();
        
            // Print the third vertical line with values for each card
            for (int i = 0; i < number_of_cards; i++) {
                System.out.print(thirdVerticalLines[i] + " ");
            }
            System.out.println();
        
            // Print the bottom line for each card
            for (int i = 0; i < number_of_cards; i++) {
                System.out.print(bottomLine + " ");
            }
        }    
    }

    //To determine the first one to draw a card, prompt the user to select from Head or Tail and used it as the basis.
    public static String[] toss_Coin_and_display_result(Scanner scan, Random random) {
        String[] first_sec_third = new String[3];
        String[] players = {"Human", "Computer 1", "Computer 2"};
        
        System.out.println("Human, please pick head or tail:");
        //String toss_coin_choice = scan.nextLine();
        String toss_coin_choice = ""; 
        System.out.println();
        while (true){
            toss_coin_choice = scan.nextLine();
            if (toss_coin_choice.equalsIgnoreCase("Head") || toss_coin_choice.equalsIgnoreCase("Tail")){//Check if not head or tail
                break; 
            } else {
                System.out.println("Please enter your choice!");
                continue; 
            }
        }

        String res = toss_Coin(random);
        
        if (toss_coin_choice.equalsIgnoreCase(res)) {
            System.out.println(players[0] + ", you're first to draw a card");
            first_sec_third[0] = players[0];
            
            // Determine the opponent of the human (Computer 1)
            int com1_or_2 = random.nextInt(2);
            first_sec_third[1] = players[(com1_or_2 == 0) ? 1 : 2]; // Assign com1 or com2 to the second player
            first_sec_third[2] = players[(com1_or_2 == 0) ? 2 : 1]; // Assign the remaining player to the third player
        } else {
            first_sec_third[0] = players[1]; // Assign the computer one who won the toss as the first player
            //Human or Com2
            int winner_index = random.nextInt(2);         
            first_sec_third[1] = players[(winner_index == 0) ? 0 : 2]; 
            first_sec_third[2] = players[(winner_index == 0) ? 2 : 0];
        }
        return first_sec_third;
    }

    //Randomly toss coin
    public static String toss_Coin(Random random) {
        String[] head_or_tail = {"Head","Tail"}; 
        int ran = random.nextInt(2);  
        return head_or_tail[ran]; 
    }

    //Display the placer in the toss coin 
    public static void display_placer(String[] win_sec_third){
        String[] name_order = {"First ", "Second ", "Third "}; 
        int n_c = 0;
        for (String s: name_order){
            System.out.println(s+"is "+win_sec_third[n_c++]);
        }
        System.out.println();
    }

    //Pick winner one card from the opponent cards
    public static String pick_one_card_in_opponent(String[] opponent_card, int index_of_choose){
        if ((index_of_choose  - 1  >= 0 || index_of_choose -1 < opponent_card.length) && opponent_card.length != 0){
            String picked_card = ""; 
            for (int i = 0; i < opponent_card.length; i++){
                if (i == index_of_choose - 1){
                    picked_card = opponent_card[i]; 
                    continue; 
                }
            }
            return picked_card; 
        } else {
            System.out.println("Invalid choice, please choose again!");
            throw new ArrayIndexOutOfBoundsException();
        }
    }   

    //Modify the card by increasing one length of the array and adding picked card from the opponent at the last index of new array
    public static String[] add_one_in_the_current_player(String[] previous_card, String card_picked){
        String[] current_card = new String[previous_card.length+1]; 
        for (int i = 0; i < previous_card.length; i++){
            current_card[i] = previous_card[i]; 
        }
        current_card[previous_card.length] = card_picked;
        return current_card;
    }

    public static void display_picked_card(String card){
        String suit = "";
        String value = ""; 
        int valueLength = 0;
        String[] parts = card.split("_");
        suit = parts[0];
        value = parts[1];
        valueLength = value.length();    
    
        picked_card_icon(suit, value, valueLength);        
    }

    public static void picked_card_icon(String suit, String value, int valueLength){
        System.out.println("  _________");
        System.out.println(" | " + suit + "       |");
        System.out.println(" |         |  ");
        System.out.println(" |    " + value + " ".repeat(Math.max(0, 5 - valueLength)) + "|");
        System.out.println(" |_________|");
    }

    public static String[] display_pair_cards_for_player_loop(String[] player_remove_pair, String[] player_cards) {
        int size_counter = 0;
        // Count the number of cards to be returned
        for (int i = 0; i < player_cards.length; i++) {
            if (player_cards[i] != null) { // Check for null values
                boolean found = false; // Flag to check if the card is removed
                for (int j = 0; j < player_remove_pair.length; j++) {
                    if (player_remove_pair[j] != null && player_cards[i].equals(player_remove_pair[j])) {
                        found = true; // Set found to true if the card is removed
                        break; // Exit inner loop if the card is found
                    }
                }
                if (!found) {
                    size_counter++; // Increment the counter for non-removed cards
                }
            }
        }
        // Initialize the return array with the correct size
        String[] return_arr = new String[size_counter];
        int index = 0;
    

        // Populate the return array with non-removed cards
        for (int i = 0; i < player_cards.length; i++) {
            if (player_cards[i] != null) { // Check for null values
                boolean found = false; // Flag to check if the card is removed
                for (int j = 0; j < player_remove_pair.length; j++) {
                    if (player_remove_pair[j] != null && player_cards[i].equals(player_remove_pair[j])) {
                        found = true; // Set found to true if the card is removed
                        break; // Exit inner loop if the card is found
                    }
                }
                if (!found) {
                    return_arr[index++] = player_cards[i]; // Assign the card to return_arr and increment index
                }
            }
        }
        System.out.println();
        return return_arr; 
    }

    public static void display_remaining_card_with_icon1_loop(String[][] three_card) {
        String[] name = {"Human", "Computer 1", "Computer 2"}; 
        
        for (int i = 0; i < three_card.length; i++) {
            System.out.println(name[i] + " here is your card:");
            
            String[] suit = new String[three_card[i].length];
            String[] value = new String[three_card[i].length]; 
            int[] valueLength = new int[three_card[i].length];
            
            for (int j = 0; j < three_card[i].length; j++) {
                String cards = three_card[i][j];
                if (cards == null) continue;
                
                String[] parts = cards.split("_");
                suit[j] = parts[0];
                value[j] = parts[1];
                valueLength[j] = value[j].length();    
            } 
            
            int number_of_cards = three_card[i].length;
            display_remaining_card_with_icon2(suit, value, valueLength, number_of_cards);
            System.out.println();
        }
    }

    public static void pair_card_loop(String[] two_card){
        if (two_card.length == 0){
            card_icon_no_pair();
            return; 
        } else {
            String[] suit = new String[2];
            String[] value = new String[2]; 
            int[] valueLength = new int[2];
            for (int i = 0; i < two_card.length; i++) {
                String[] parts = two_card[i].split("_");
                suit[i] = parts[0];
                value[i] = parts[1];
                valueLength[i] = value[i].length();    
            } 
            card_icon_loop(suit, value, valueLength);        
        }
    }
    public static void hidden_and_last_card(String[] two_card){
        String[] suit = new String[2];
        String[] value = new String[2]; 
        int[] valueLength = new int[2];
        for (int i = 0; i < two_card.length; i++) {
            String[] parts = two_card[i].split("_");
            suit[i] = parts[0];
            value[i] = parts[1];
            valueLength[i] = value[i].length();    
        } 
        hidden_last(suit, value, valueLength);        
    }
    //OVERLOAD METHOD 
    public static void display_remaining_card_with_icon1(String[] human_natitirang_card, String[] com1_natitirang_card, String[] com2_natitirang_card){
        String[][] three_player = {human_natitirang_card, com1_natitirang_card, com2_natitirang_card};
        String[] name = {"Human", "Computer 1", "Computer 2"}; 
        for (int i = 0; i < three_player.length; i++){
            String[] suit = new String[three_player[i].length];
            String[] value = new String[three_player[i].length]; 
            int[] valueLength = new int[three_player[i].length];
            System.out.println(name[i]+" here is your remaining card");
            if (three_player[i].length == 0){
                draw_all_card();
            } else {
                for (int j = 0; j < three_player[i].length; j++) {
                    String card = three_player[i][j];
                    if (card == null) continue;
                    String[] parts = card.split("_");
                    suit[j] = parts[0];
                    value[j] = parts[1];
                    valueLength[j] = value[j].length();    
                } 
                display_remaining_card_with_icon2(suit, value, valueLength, three_player[i].length);
                System.out.println();
            }
        }
    }

    //DEBUGIING --------------------------------------------------------------
    public static void display_remaining_card_with_icon1(String[] patira1, String[] patira2, String[] patira3, String name1, String name2, String name3){
        String[][] three_player = {patira1, patira2, patira3};
        String[] name = {name1, name2, name3}; 
        for (int i = 0; i < three_player.length; i++){
            String[] suit = new String[three_player[i].length];
            String[] value = new String[three_player[i].length]; 
            int[] valueLength = new int[three_player[i].length];
            System.out.println(name[i]+" here is your remaining card");
            if (three_player[i].length == 0){
                draw_all_card();
            } else {
                for (int j = 0; j < three_player[i].length; j++){
                    String card = three_player[i][j];
                    if (card == null) continue;
                    String[] parts = card.split("_");
                    suit[j] = parts[0];
                    value[j] = parts[1];
                    valueLength[j] = value[j].length();    
                } 
                display_remaining_card_with_icon2(suit, value, valueLength, three_player[i].length);
                System.out.println();
            }
        }
    }

    public static void display_remaining_card_with_icon2(String[] suits, String[] values, int[] valueLength, int number_of_cards) {
        if (number_of_cards > 10){
            int first_row_size = Math.min(10, number_of_cards);
            //int second_row_size = number_of_cards - first_row_size;
            
            String horizontalLine = "  _________";
            String[] firstVerticalLines = new String[number_of_cards];
            String[] secondVerticalLines = new String[number_of_cards];
            String[] thirdVerticalLines = new String[number_of_cards];
            String bottomLine = " |_________|";
            
            // Construct the card icon lines for each card
            for (int i = 0; i < number_of_cards; i++) {
                firstVerticalLines[i] = String.format(" | %s       |", suits[i]);
                secondVerticalLines[i] = " |         |";
                thirdVerticalLines[i] = String.format(" |    %s|", values[i] + " ".repeat(Math.max(0, 5 - valueLength[i])));
            }
            
            // First row 
            // Print the card icons horizontally
            for (int i = 0; i < first_row_size; i++) {
                // Print the concatenated strings for each line of the card icon
                System.out.print(horizontalLine + "  ");
            }
            System.out.println(); // Print a new line after printing all horizontal lines
            
            // Print the first vertical line for each card
            for (int i = 0; i < first_row_size; i++) {
                System.out.print(firstVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the second vertical line for each card
            for (int i = 0; i < first_row_size; i++) {
                System.out.print(secondVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the third vertical line with values for each card
            for (int i = 0; i < first_row_size; i++) {
                System.out.print(thirdVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the bottom line for each card
            for (int i = 0; i < first_row_size; i++) {
                System.out.print(bottomLine + " ");
            }
            System.out.println();
            
            // Second row 
            for (int i = first_row_size; i < number_of_cards; i++) {
                // Print the card icons horizontally for the second row
                System.out.print(horizontalLine + "  ");
            }
            System.out.println(); // Print a new line after printing all horizontal lines
            
            // Print the first vertical line for each card in the second row
            for (int i = first_row_size; i < number_of_cards; i++) {
                System.out.print(firstVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the second vertical line for each card in the second row
            for (int i = first_row_size; i < number_of_cards; i++) {
                System.out.print(secondVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the third vertical line with values for each card in the second row
            for (int i = first_row_size; i < number_of_cards; i++) {
                System.out.print(thirdVerticalLines[i] + " ");
            }
            System.out.println();
            
            // Print the bottom line for each card in the second row
            for (int i = first_row_size; i < number_of_cards; i++) {
                System.out.print(bottomLine + " ");
            }
        } else {
            // Initialize the card icon lines outside the loop
            String horizontalLine = "  _________";
            String[] firstVerticalLines = new String[number_of_cards];
            String[] secondVerticalLines = new String[number_of_cards];
            String[] thirdVerticalLines = new String[number_of_cards];
            String bottomLine = " |_________|";
        
            // Construct the card icon lines for each card
            for (int i = 0; i < number_of_cards; i++) {
                firstVerticalLines[i] = String.format(" | %s       |", suits[i]);
                secondVerticalLines[i] = " |         |";
                thirdVerticalLines[i] = String.format(" |    %s|", values[i] + " ".repeat(Math.max(0, 5 - valueLength[i])));
            }
        
            // Print the card icons horizontally
            for (int i = 0; i < number_of_cards; i++) {
                // Print the concatenated strings for each line of the card icon
                System.out.print(horizontalLine + "  ");
            }
            System.out.println(); // Print a new line after printing all horizontal lines
        
            // Print the first vertical line for each card
            for (int i = 0; i < number_of_cards; i++) {
                System.out.print(firstVerticalLines[i] + " ");
            }
            System.out.println();
        
            // Print the second vertical line for each card
            for (int i = 0; i < number_of_cards; i++) {
                System.out.print(secondVerticalLines[i] + " ");
            }
            System.out.println();
        
            // Print the third vertical line with values for each card
            for (int i = 0; i < number_of_cards; i++) {
                System.out.print(thirdVerticalLines[i] + " ");
            }
            System.out.println();
        
            // Print the bottom line for each card
            for (int i = 0; i < number_of_cards; i++) {
                System.out.print(bottomLine + " ");
            }
        }    
    }

    public static void display_card_51(String[] card_51){
        String[] suit = new String[52];
        String[] value = new String[52]; 
        int[] valueLength = new int[52];
        for (int i = 0; i < card_51.length; i++) {
            String[] parts = card_51[i].split("_");
            suit[i] = parts[0];
            value[i] = parts[1];
            valueLength[i] = value[i].length();             
            // Display the card
        }
        card_icon_for_51(suit, value, valueLength);
    }

    public static void card_icon_for_51(String[] suit, String[] value, int[] valueLength){
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[0] + "       |"+"      "+" | "  + suit[1] + "       |"+"      "+" | " + suit[2] + "       |"+"       "+" | " + suit[3] + "       |"+"      "+" | "  + suit[4] + "       |"+"      "+" | " + suit[5] + "       |"+"      "+" | "  + suit[6] + "       |"+"      "+" | "  + suit[7] + "       |"+"      "+" | "  + suit[8] + "       |"+"       | "  + suit[9] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[0] + " ".repeat(Math.max(0, 5 - valueLength[0])) + "|"+"      "+" |    " + value[1] + " ".repeat(Math.max(0, 5 - valueLength[1])) + "|"+"      "+" |    " + value[2] + " ".repeat(Math.max(0, 5 - valueLength[2])) + "|"+"       "+" |    " + value[3] + " ".repeat(Math.max(0, 5 - valueLength[3])) + "|"+"      "+" |    " + value[4] + " ".repeat(Math.max(0, 5 - valueLength[4])) + "|"+"      "+" |    " + value[5] + " ".repeat(Math.max(0, 5 - valueLength[5])) + "|"+"      "+" |    " + value[6] + " ".repeat(Math.max(0, 5 - valueLength[6])) + "|"+"      "+" |    " + value[7] + " ".repeat(Math.max(0, 5 - valueLength[7])) + "|"+"      "+" |    " + value[8] + " ".repeat(Math.max(0, 5 - valueLength[8])) + "|"+"       |    " + value[9] + " ".repeat(Math.max(0, 5 - valueLength[9])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
       
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[10] + "       |"+"      "+" | "  + suit[11] + "       |"+"      "+" | " + suit[12] + "       |"+"       "+" | " + suit[13] + "       |"+"      "+" | "  + suit[14] + "       |"+"      "+" | " + suit[15] + "       |"+"      "+" | "  + suit[16] + "       |"+"      "+" | "  + suit[17] + "       |"+"      "+" | "  + suit[18] + "       |"+"       | "  + suit[19] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[10] + " ".repeat(Math.max(0, 5 - valueLength[10])) + "|"+"      "+" |    " + value[11] + " ".repeat(Math.max(0, 5 - valueLength[11])) + "|"+"      "+" |    " + value[12] + " ".repeat(Math.max(0, 5 - valueLength[12])) + "|"+"       "+" |    " + value[13] + " ".repeat(Math.max(0, 5 - valueLength[13])) + "|"+"      "+" |    " + value[14] + " ".repeat(Math.max(0, 5 - valueLength[14])) + "|"+"      "+" |    " + value[15] + " ".repeat(Math.max(0, 5 - valueLength[15])) + "|"+"      "+" |    " + value[16] + " ".repeat(Math.max(0, 5 - valueLength[16])) + "|"+"      "+" |    " + value[17] + " ".repeat(Math.max(0, 5 - valueLength[17])) + "|"+"      "+" |    " + value[18] + " ".repeat(Math.max(0, 5 - valueLength[18])) + "|"+"       |    " + value[19] + " ".repeat(Math.max(0, 5 - valueLength[19])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
             
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[20] + "       |"+"      "+" | "  + suit[21] + "       |"+"      "+" | " + suit[22] + "       |"+"       "+" | " + suit[23] + "       |"+"      "+" | "  + suit[24] + "       |"+"      "+" | " + suit[25] + "       |"+"      "+" | "  + suit[26] + "       |"+"      "+" | "  + suit[27] + "       |"+"      "+" | "  + suit[28] + "       |"+"       | "  + suit[29] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[20] + " ".repeat(Math.max(0, 5 - valueLength[20])) + "|"+"      "+" |    " + value[21] + " ".repeat(Math.max(0, 5 - valueLength[21])) + "|"+"      "+" |    " + value[22] + " ".repeat(Math.max(0, 5 - valueLength[22])) + "|"+"       "+" |    " + value[23] + " ".repeat(Math.max(0, 5 - valueLength[23])) + "|"+"      "+" |    " + value[24] + " ".repeat(Math.max(0, 5 - valueLength[24])) + "|"+"      "+" |    " + value[25] + " ".repeat(Math.max(0, 5 - valueLength[25])) + "|"+"      "+" |    " + value[26] + " ".repeat(Math.max(0, 5 - valueLength[26])) + "|"+"      "+" |    " + value[27] + " ".repeat(Math.max(0, 5 - valueLength[27])) + "|"+"      "+" |    " + value[28] + " ".repeat(Math.max(0, 5 - valueLength[28])) + "|"+"       |    " + value[29] + " ".repeat(Math.max(0, 5 - valueLength[29])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
       
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[30] + "       |"+"      "+" | "  + suit[31] + "       |"+"      "+" | " + suit[32] + "       |"+"       "+" | " + suit[33] + "       |"+"      "+" | "  + suit[34] + "       |"+"      "+" | " + suit[35] + "       |"+"      "+" | "  + suit[36] + "       |"+"      "+" | "  + suit[37] + "       |"+"      "+" | "  + suit[38] + "       |"+"       | "  + suit[39] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[30] + " ".repeat(Math.max(0, 5 - valueLength[30])) + "|"+"      "+" |    " + value[31] + " ".repeat(Math.max(0, 5 - valueLength[31])) + "|"+"      "+" |    " + value[32] + " ".repeat(Math.max(0, 5 - valueLength[32])) + "|"+"       "+" |    " + value[33] + " ".repeat(Math.max(0, 5 - valueLength[33])) + "|"+"      "+" |    " + value[34] + " ".repeat(Math.max(0, 5 - valueLength[34])) + "|"+"      "+" |    " + value[35] + " ".repeat(Math.max(0, 5 - valueLength[35])) + "|"+"      "+" |    " + value[36] + " ".repeat(Math.max(0, 5 - valueLength[36])) + "|"+"      "+" |    " + value[37] + " ".repeat(Math.max(0, 5 - valueLength[37])) + "|"+"      "+" |    " + value[38] + " ".repeat(Math.max(0, 5 - valueLength[38])) + "|"+"       |    " + value[39] + " ".repeat(Math.max(0, 5 - valueLength[39])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
        
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[40] + "       |"+"      "+" | "  + suit[41] + "       |"+"      "+" | " + suit[42] + "       |"+"       "+" | " + suit[43] + "       |"+"      "+" | "  + suit[44] + "       |"+"      "+" | " + suit[45] + "       |"+"      "+" | "  + suit[46] + "       |"+"      "+" | "  + suit[47] + "       |"+"      "+" | "  + suit[48] + "       |"+"       | "  + suit[49] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[40] + " ".repeat(Math.max(0, 5 - valueLength[40])) + "|"+"      "+" |    " + value[41] + " ".repeat(Math.max(0, 5 - valueLength[41])) + "|"+"      "+" |    " + value[42] + " ".repeat(Math.max(0, 5 - valueLength[42])) + "|"+"       "+" |    " + value[43] + " ".repeat(Math.max(0, 5 - valueLength[43])) + "|"+"      "+" |    " + value[44] + " ".repeat(Math.max(0, 5 - valueLength[44])) + "|"+"      "+" |    " + value[45] + " ".repeat(Math.max(0, 5 - valueLength[45])) + "|"+"      "+" |    " + value[46] + " ".repeat(Math.max(0, 5 - valueLength[46])) + "|"+"      "+" |    " + value[47] + " ".repeat(Math.max(0, 5 - valueLength[47])) + "|"+"      "+" |    " + value[48] + " ".repeat(Math.max(0, 5 - valueLength[48])) + "|"+"       |    " + value[49] + " ".repeat(Math.max(0, 5 - valueLength[49])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
       
        System.out.println("  _________"+"        "+" _________");
        System.out.println(" | " + suit[50] + "       |"+"      "+" | "  + suit[51] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  ");
        System.out.println(" |    " + value[50] + " ".repeat(Math.max(0, 5 - valueLength[50])) + "|"+"      "+" |    " + value[51] + " ".repeat(Math.max(0, 5 - valueLength[51])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|");
           

    }
    public static void display_shuffle(String[] card_51){
        String[] suit = new String[51];
        String[] value = new String[51]; 
        int[] valueLength = new int[51];
        for (int i = 0; i < card_51.length; i++) {
            String[] parts = card_51[i].split("_");
            suit[i] = parts[0];
            value[i] = parts[1];
            valueLength[i] = value[i].length();             
            // Display the card
        }
        display_shuffle_sub_method(suit, value, valueLength);
    }

    public static void display_shuffle_sub_method(String[] suit, String[] value, int[] valueLength){
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[0] + "       |"+"      "+" | "  + suit[1] + "       |"+"      "+" | " + suit[2] + "       |"+"       "+" | " + suit[3] + "       |"+"      "+" | "  + suit[4] + "       |"+"      "+" | " + suit[5] + "       |"+"      "+" | "  + suit[6] + "       |"+"      "+" | "  + suit[7] + "       |"+"      "+" | "  + suit[8] + "       |"+"       | "  + suit[9] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[0] + " ".repeat(Math.max(0, 5 - valueLength[0])) + "|"+"      "+" |    " + value[1] + " ".repeat(Math.max(0, 5 - valueLength[1])) + "|"+"      "+" |    " + value[2] + " ".repeat(Math.max(0, 5 - valueLength[2])) + "|"+"       "+" |    " + value[3] + " ".repeat(Math.max(0, 5 - valueLength[3])) + "|"+"      "+" |    " + value[4] + " ".repeat(Math.max(0, 5 - valueLength[4])) + "|"+"      "+" |    " + value[5] + " ".repeat(Math.max(0, 5 - valueLength[5])) + "|"+"      "+" |    " + value[6] + " ".repeat(Math.max(0, 5 - valueLength[6])) + "|"+"      "+" |    " + value[7] + " ".repeat(Math.max(0, 5 - valueLength[7])) + "|"+"      "+" |    " + value[8] + " ".repeat(Math.max(0, 5 - valueLength[8])) + "|"+"       |    " + value[9] + " ".repeat(Math.max(0, 5 - valueLength[9])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
       
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[10] + "       |"+"      "+" | "  + suit[11] + "       |"+"      "+" | " + suit[12] + "       |"+"       "+" | " + suit[13] + "       |"+"      "+" | "  + suit[14] + "       |"+"      "+" | " + suit[15] + "       |"+"      "+" | "  + suit[16] + "       |"+"      "+" | "  + suit[17] + "       |"+"      "+" | "  + suit[18] + "       |"+"       | "  + suit[19] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[10] + " ".repeat(Math.max(0, 5 - valueLength[10])) + "|"+"      "+" |    " + value[11] + " ".repeat(Math.max(0, 5 - valueLength[11])) + "|"+"      "+" |    " + value[12] + " ".repeat(Math.max(0, 5 - valueLength[12])) + "|"+"       "+" |    " + value[13] + " ".repeat(Math.max(0, 5 - valueLength[13])) + "|"+"      "+" |    " + value[14] + " ".repeat(Math.max(0, 5 - valueLength[14])) + "|"+"      "+" |    " + value[15] + " ".repeat(Math.max(0, 5 - valueLength[15])) + "|"+"      "+" |    " + value[16] + " ".repeat(Math.max(0, 5 - valueLength[16])) + "|"+"      "+" |    " + value[17] + " ".repeat(Math.max(0, 5 - valueLength[17])) + "|"+"      "+" |    " + value[18] + " ".repeat(Math.max(0, 5 - valueLength[18])) + "|"+"       |    " + value[19] + " ".repeat(Math.max(0, 5 - valueLength[19])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
             
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[20] + "       |"+"      "+" | "  + suit[21] + "       |"+"      "+" | " + suit[22] + "       |"+"       "+" | " + suit[23] + "       |"+"      "+" | "  + suit[24] + "       |"+"      "+" | " + suit[25] + "       |"+"      "+" | "  + suit[26] + "       |"+"      "+" | "  + suit[27] + "       |"+"      "+" | "  + suit[28] + "       |"+"       | "  + suit[29] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[20] + " ".repeat(Math.max(0, 5 - valueLength[20])) + "|"+"      "+" |    " + value[21] + " ".repeat(Math.max(0, 5 - valueLength[21])) + "|"+"      "+" |    " + value[22] + " ".repeat(Math.max(0, 5 - valueLength[22])) + "|"+"       "+" |    " + value[23] + " ".repeat(Math.max(0, 5 - valueLength[23])) + "|"+"      "+" |    " + value[24] + " ".repeat(Math.max(0, 5 - valueLength[24])) + "|"+"      "+" |    " + value[25] + " ".repeat(Math.max(0, 5 - valueLength[25])) + "|"+"      "+" |    " + value[26] + " ".repeat(Math.max(0, 5 - valueLength[26])) + "|"+"      "+" |    " + value[27] + " ".repeat(Math.max(0, 5 - valueLength[27])) + "|"+"      "+" |    " + value[28] + " ".repeat(Math.max(0, 5 - valueLength[28])) + "|"+"       |    " + value[29] + " ".repeat(Math.max(0, 5 - valueLength[29])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
       
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[30] + "       |"+"      "+" | "  + suit[31] + "       |"+"      "+" | " + suit[32] + "       |"+"       "+" | " + suit[33] + "       |"+"      "+" | "  + suit[34] + "       |"+"      "+" | " + suit[35] + "       |"+"      "+" | "  + suit[36] + "       |"+"      "+" | "  + suit[37] + "       |"+"      "+" | "  + suit[38] + "       |"+"       | "  + suit[39] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[30] + " ".repeat(Math.max(0, 5 - valueLength[30])) + "|"+"      "+" |    " + value[31] + " ".repeat(Math.max(0, 5 - valueLength[31])) + "|"+"      "+" |    " + value[32] + " ".repeat(Math.max(0, 5 - valueLength[32])) + "|"+"       "+" |    " + value[33] + " ".repeat(Math.max(0, 5 - valueLength[33])) + "|"+"      "+" |    " + value[34] + " ".repeat(Math.max(0, 5 - valueLength[34])) + "|"+"      "+" |    " + value[35] + " ".repeat(Math.max(0, 5 - valueLength[35])) + "|"+"      "+" |    " + value[36] + " ".repeat(Math.max(0, 5 - valueLength[36])) + "|"+"      "+" |    " + value[37] + " ".repeat(Math.max(0, 5 - valueLength[37])) + "|"+"      "+" |    " + value[38] + " ".repeat(Math.max(0, 5 - valueLength[38])) + "|"+"       |    " + value[39] + " ".repeat(Math.max(0, 5 - valueLength[39])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
        
        System.out.println("  _________"+"        "+" _________"+"         _________"+"         "+" _________"+"        "+" _________"+"         _________"+"         _________"+"         _________"+"         _________"+"         _________");
        System.out.println(" | " + suit[40] + "       |"+"      "+" | "  + suit[41] + "       |"+"      "+" | " + suit[42] + "       |"+"       "+" | " + suit[43] + "       |"+"      "+" | "  + suit[44] + "       |"+"      "+" | " + suit[45] + "       |"+"      "+" | "  + suit[46] + "       |"+"      "+" | "  + suit[47] + "       |"+"      "+" | "  + suit[48] + "       |"+"       | "  + suit[49] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  "+"     |         |  "+"     "+" |         |  "+"    "+" |         |  "+"     |         |"+"       |         |"+"       |         |"+"       |         |"+"       |         |");
        System.out.println(" |    " + value[40] + " ".repeat(Math.max(0, 5 - valueLength[40])) + "|"+"      "+" |    " + value[41] + " ".repeat(Math.max(0, 5 - valueLength[41])) + "|"+"      "+" |    " + value[42] + " ".repeat(Math.max(0, 5 - valueLength[42])) + "|"+"       "+" |    " + value[43] + " ".repeat(Math.max(0, 5 - valueLength[43])) + "|"+"      "+" |    " + value[44] + " ".repeat(Math.max(0, 5 - valueLength[44])) + "|"+"      "+" |    " + value[45] + " ".repeat(Math.max(0, 5 - valueLength[45])) + "|"+"      "+" |    " + value[46] + " ".repeat(Math.max(0, 5 - valueLength[46])) + "|"+"      "+" |    " + value[47] + " ".repeat(Math.max(0, 5 - valueLength[47])) + "|"+"      "+" |    " + value[48] + " ".repeat(Math.max(0, 5 - valueLength[48])) + "|"+"       |    " + value[49] + " ".repeat(Math.max(0, 5 - valueLength[49])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|"+"       |_________|"+"       "+" |_________|"+"      "+" |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|"+"       |_________|");
       
        System.out.println("  _________");
        System.out.println(" | " + suit[50] + "       |");
        System.out.println(" |         |  ");
        System.out.println(" |    " + value[50] + " ".repeat(Math.max(0, 5 - valueLength[50])) + "|");
        System.out.println(" |_________|");
           
    }
    //Method for pairing last char of the card name 
    public static boolean isPair(String card1, String card2) {
        return card1.substring(2).equals(card2.substring(2)); // Compare entire card strings
    }
    public static void card_icon_loop(String[] suit, String[] value, int[] valueLength){
        System.out.println("  _________"+"        "+" _________");
        System.out.println(" | " + suit[0] + "       |"+"      "+" | " + suit[1] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  ");
        System.out.println(" |    " + value[0] + " ".repeat(Math.max(0, 5 - valueLength[0])) + "|"+"      "+" |    " + value[1] + " ".repeat(Math.max(0, 5 - valueLength[1])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|");
    }
    public static void card_icon_picked_first(String suit, String value, int valueLength){
        System.out.println("  _________");
        System.out.println(" | " + suit + "       |");
        System.out.println(" |         |  ");
        System.out.println(" |    " + value + " ".repeat(Math.max(0, 5 - valueLength)) + "|");
        System.out.println(" |_________|");
    }
    public static void card_icon_no_pair(){
        System.out.println("  _________ ");
        System.out.println(" |         | ");
        System.out.println(" |  NO     |");
        System.out.println(" |  PAIR!  |");
        System.out.println(" |_________|");
    }
    public static void draw_all_card(){
        System.out.println("  _________ ");
        System.out.println(" |  Already| ");
        System.out.println(" |   Drop  |");
        System.out.println(" |   Card  |");
        System.out.println(" |_________|");
    }
    public static void hidden_last(String[] suit, String[] value, int[] valueLength){
        System.out.println("  _________"+"        "+" _________");
        System.out.println(" | " + suit[0] + "       |"+"      "+" | " + suit[1] + "       |");
        System.out.println(" |         |  "+"    "+" |         |  ");
        System.out.println(" |    " + value[0] + " ".repeat(Math.max(0, 5 - valueLength[0])) + "|"+"      "+" |    " + value[1] + " ".repeat(Math.max(0, 5 - valueLength[1])) + "|");
        System.out.println(" |_________|"+"      "+" |_________|");
    
        System.out.println();
    }



    //Array of my deck(you know)
    public static String[] decs_of_cards(){
        String[] decs_arr = {
            "C_1", "C_2", "C_3", "C_4", "C_5", "C_6", "C_7", "C_8", "C_9", "C_10", "C_11", "C_12", "C_13",
            "D_1", "D_2", "D_3", "D_4", "D_5", "D_6", "D_7", "D_8", "D_9", "D_10", "D_11", "D_12", "D_13",
            "H_1", "H_2", "H_3", "H_4", "H_5", "H_6", "H_7", "H_8", "H_9", "H_10", "H_11", "H_12", "H_13",
            "S_1", "S_2", "S_3", "S_4", "S_5", "S_6", "S_7", "S_8", "S_9", "S_10", "S_11", "S_12", "S_13"
        }; 
        return decs_arr; 
    }
    public static void welcome() {
        // Drawing first monkey
        System.out.println(
                "#####################################################################################################################################");
        System.out.println(
                "#####################################################################################################################################");
        System.out.println(
                "#####################################################################################################################################");
        System.out.println(
                "################## ##                 ## ######### ###      ########### ########## ####       ####  ###########  ####################");
        System.out.println(
                "##################  ##               ##  ######### ###      ########### ########## ## ##     ## ##  ###########  ####################");
        System.out.println(
                "##################   ##     ###     ##   ###       ###      ##       ## ###    ### ##  ##   ##  ##  ###          ####################");
        System.out.println(
                "##################    ##   ## ##   ##    ######    ###      ##          ##      ## ##   ## ##   ##  ######       ####################");
        System.out.println(
                "##################     ## ##   ## ##     ###       ###      ##       ## ###    ### ##    ##     ##  ###          ####################");
        System.out.println(
                "##################       ##     ##       ######### ######## ########### ########## ##           ##  ###########  ####################");
        System.out.println(
                "##################        #     #        ######### ######## ########### ########## ##           ##  ###########  ####################");
        System.out.println(
                "##################                                                                                               ####################");
        System.out.println(
                "##################                                                                                               ####################");
        System.out.println(
                "################## ##############   #############   ############## ###        ###  ############                  ####################");
        System.out.println(
                "################## ##############  ###############  ############## ###        ###  ############                  ####################");
        System.out.println(
                "##################     #####       ####       ####      #####      ###        ###  ###                           ####################");
        System.out.println(
                "##################     #####       ###         ###      #####      ##############  #######                       ####################");
        System.out.println(
                "##################     #####       ####       ####      #####      ##############  ###                           ####################");
        System.out.println(
                "##################     #####       ###############      #####      ###        ###  ############                  ####################");
        System.out.println(
                "##################     #####        #############       #####      ###        ###  ############                  ####################");
        System.out.println(
                "##################                                                                                               ####################");
        System.out.println(
                "##################                                                                                               ####################");
        System.out.println(
                "##################    ###############           #######        #####           #####   ###############  #####    ####################");
        System.out.println(
                "##################   #################        ####  ####       ### ###       ### ###   ###############  #####    ####################");
        System.out.println(
                "##################  ####           ####      ####    ####      ###  ###     ###  ###   ###              #####    ####################");
        System.out.println(
                "##################  ###                     ####      ####     ###   ###   ###   ###   ########          ###     ####################");
        System.out.println(
                "##################  ###         #######    ################    ###    ### ###    ###   ########          ###     ####################");
        System.out.println(
                "#################   ####           ####   ##################   ###     #####     ###   ###               ###     ####################");
        System.out.println(
                "##################  ###################  ####            ####  ###               ###   ##############            ####################");
        System.out.println(
                "##################   #################  ####              #### ###               ###   ##############    ###     ####################");
        System.out.println(
                "##################                                                                                               ####################");
        System.out.println(
                "#####################################################################################################################################");
        System.out.println(
                "#####################################################################################################################################");
        System.out.println(
                "#####################################################################################################################################");
        System.out.println(
                "#####################################################################################################################################");
        System.out.println(
                "                                                                                                                             ");
    }
    public static void drawing() {
        // Drawing first monkey
        System.out.println("                                           #                                                                    #                                               ");
        System.out.println("                                           # #                                                                # #                                             ");
        System.out.println("                                          #    #                                                             #    #                                              ");
        System.out.println("                                          #      #                                                          #       #                                              ");
        System.out.println("                                         #  0   0 #                                                        #  0   0   #                                           ");
        System.out.println("                                          #         #                                                       #         #                                            ");
        System.out.println("                                            #  ^  #                                                           #   ^  #                                            ");
        System.out.println("                                            #     #                                                           #      #                                            ");
        System.out.println("                                             # ___ #                                                           #  ___ #                                           ");
        System.out.println("                                            # #     # #                                                      # #      # #                                          ");
        System.out.println("                                          #    # # #    #                                                  #     # # #    #                                           ");
        System.out.println("                                        #                #                                               #                #        ##                            ");
        System.out.println("                                       #                   #                                           #                   #    ##  ##                            ");
        System.out.println("                                     #     # #       # #    #                                         #    # #         #     # ##     ##                         ");
        System.out.println("                              ##    #    #    #       #  #    #                                     #   #    #        #  #    #                              ");
        System.out.println("                            ## ##  #    #     #       #   #    #                                  #   #      #        #   ##   #                              ");
        System.out.println("                          ##   ## #   #      #       #     #    #                                #   #       #        #  ## #   #                                 ");
        System.out.println("                         ##      #   #       #       #      #    #                            #   #          #        # ##   #   #                                 ");
        System.out.println("                        #       # #  ##      #        #       #  #                           #  # #          #         ###     # # #                                ");
        System.out.println("                              # # #   ##    #         #       # # #                        # # # #         #           #     # # # # #                                          ");
        System.out.println("                           # # # # #   ###             #     # # # # #                   # # # #  #      #              #  #   # # # #                                      ");
        System.out.println("                                        #                #                                             #                #                                     ");
        System.out.println("                                      #        #          #                                          #       # #      #                                        ");
        System.out.println("                                    #       #    #         #                                       #      #      #     #                                        ");
        System.out.println("                                     #     #        #      #                                        #   #        #    #                                       ");
        System.out.println("                                      #    #        #    #                                          #   #       #    #                                       ");
        System.out.println("                                       #  #        #   #                                              #  #      #   #                                        ");
        System.out.println("                                       # #        #  #                                                  # #      # #                                         ");
        System.out.println("                                        #           #                                                     #       #                                      ");
        System.out.println("=====================================/=\\=\\=====/=\\=\\=====================================================/=/=\\==/=/=\\=======================================                                                                                         ");
        System.out.println("                                                                                                                             ");
        System.out.println("                                                                                                                              ");
    }
}

